Existing benchmark observations only; no new solver analyses.
The selected comparison table contains historical 5-010 NEWSOLID buckling values. These are superseded by CASE_5010/parity_fixed/validation.json: 3.949972 kip (2x1x12) and 1.438476 kip (4x1x24). The manuscript uses those corrected results. All other reported selected-case values retain the existing observations.

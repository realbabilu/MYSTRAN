Existing benchmark results only. No solver was run for this report.
Beam and dome observations are the CPENTA6/ABE rows in update/solid_benchmark/comparison_all.zip, source commit 1ad885af3ff542621178ce5b0269e3a49dac8d5c. The original observation strings are preserved.
The relative result-array comparisons include other formulations; Section 7.6.3 uses the ABE rows of uniform-temperature case 5011 only.
The historical f=0/f=1 studies in the report remain separate from the matched-model ABE archive; no unrecorded mean-correction setting is inferred.

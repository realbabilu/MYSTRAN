# CHEXA8 TIED � manual Nastran jobs

20 standalone Nastran decks from the corrected 18 October 2026 regression. Run `run_nastran.bat` after activating the appropriate license. The executable path can be edited in that file. Jobs run sequentially, with scratch and logs inside this folder. Inspect each F06: USER FATAL 3060 may accompany exit code zero.

Cases: 5-001 (six affine states plus rigid rotation), 5-004 native beam, 5-007 dome 8/16/24, 5-008 plane-strain cylinder (five material/mesh selections), 5-010 actual-preload buckling, and 5-011 free/restrained uniform and restrained gradient thermal cases. `manifest.json` records source and translation scope. These are Nastran-only inputs without MYSTRAN selectors.

Keep the matching basename DAT, F06, OP2 and LOG files. Do not rename outputs to a different benchmark. Existing failed license logs have not been copied into this clean run directory.

@echo off
setlocal
set "NASTRAN_EXE=C:\Program Files\Siemens\Femap 2512\nastran\bin\nastran.exe"
cd /d "%~dp0"
if not exist "%NASTRAN_EXE%" (
 echo Nastran executable not found. Edit NASTRAN_EXE in this file.
 pause
 exit /b 1
)
if not exist "scratch" mkdir "scratch"
if not exist "logs" mkdir "logs"
for %%F in (*.dat) do (
 echo Running %%F
 "%NASTRAN_EXE%" "%%F" old=no batch=no scr=yes "sdir=%~dp0scratch" > "logs\%%~nF.stdout" 2>&1
)
echo Completed submissions. Check each F06 for USER or SYSTEM FATAL; exit code zero does not prove success.
pause

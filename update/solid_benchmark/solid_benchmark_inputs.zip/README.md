# Solid benchmark input decks

This archive contains input decks only, plus these instructions and a SHA256 manifest. It contains no OP2, F06, F04, log, PCH, NEU, binary, database or scratch output.

- comparison_all/: 56 matched mesh models, each with a Nastran input and one or two MYSTRAN inputs. CPENTA6 has separate ABE/EAS9 selections.
- five_case/: inputs used for the original patch, beam, dome, buckling and thermal comparisons.

Run each deck from its own directory with the designated solver. Nastran example: `nastran model.dat scr=yes`. MYSTRAN example: `mystran model.dat`. Keep the executable and its required runtime libraries installed separately.

Do not mix the decks between solvers: MYSTRAN decks use NEWSOLID and supported integration settings; Nastran decks use native PSOLID defaults. The coarse dome tetra decks document a geometry-check aspect-ratio limit of 150, with determinant checks retained. Quadratic midside nodes and boundary constraints are already defined.

The reports identify reconstructed versus original SAP2000 meshes and distinguish analytical/independent references from published SAP2000 values. Consult the reports before interpreting numerical differences. Raw solver outputs are deliberately excluded from this public input archive.

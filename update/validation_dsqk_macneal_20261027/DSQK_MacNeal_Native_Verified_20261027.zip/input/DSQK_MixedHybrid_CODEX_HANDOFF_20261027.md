# DSQK mixed hybrid — Codex handoff

Date: 27 October 2026. Owner: Ary Pramudito.

## Decision and scope

The user selects **mixed hybrid as the present engineering compromise**. Preserve DK as a regression baseline and MixedShear as a separate research candidate. This decision does not certify every DSQK benchmark or resolve the twisted-beam deficit.

Research in this conversation was Python-only. No Fortran source was edited here. An earlier user-supplied native report states that mixed An was already ported on isolated branch `research/dsqk-mixed-20261026`. Inspect that branch and actual build provenance before changing anything: do not assume another port is necessary.

Windows workspace: `H:\Projects\MYSTRAN`. User diagnostic folder: `H:\Projects\MYSTRAN\DSQK DSG3 upgrade\test`. Repository source is normally under `H:\Projects\MYSTRAN\source`, branch `v18.00.a`. Verify actual paths and dirty worktree first.

## Exact formulation selected

Kinematic and mixed shear compatibility:

```text
gamma_kin   = Au u + A_delta Delta
gamma_mixed = A_gamma Delta
(A_gamma - A_delta) An = Au
Delta = An u
```

Solve the linear system; do not form an explicit inverse. Use physical effective bending/shear constitutive properties and the correct inverse mapping Jacobian in derivative products.

Selected HYBRID:

```text
An = mixed elimination
Ks = integral(Bs_nodal.T Ds Bs_nodal dA)
Kb = Kbu + An.T KbDelta An   # inherited expression
```

Keep covariant nodal shear tying and consistent-spin drilling alpha=0.03. Keep existing membrane and local-basis behavior. Do not substitute `Bs_delta_mixed @ An` into Ks: that is the distinct MixedShear candidate, not the selected hybrid. Do not introduce empirical blending parameters.

The inherited omission of bending cross terms is still a derivation audit item. Do not describe the selected hybrid as a verified transcription of the complete published mixed-strain functional.

Python modules in the research package:

- `DSQK_ConsistentSpin_CovShear_ShellElement`: DK/native-matched baseline.
- `DSQK_ConsistentSpin_CovShear_MixedElimination`: selected hybrid.
- `MixedShearOnly` in `DSQK_ConsistentSpin_CovShear_FullShearCandidates`: alternative shear operator.
- Supplied `DSQK_ConsistentSpin_MixedShear`: same LC4 response as MixedShearOnly in the reproduction here.

## Why hybrid was chosen

2-002 LC4 UY/reference:

| Mesh | DK | Hybrid | MixedShear |
|---|---:|---:|---:|
| 48x4 | 0.764806 | 0.902095 | 1.028001 |
| 96x8 | 0.727616 | 0.970073 | 1.015667 |
| 192x16 | 0.704403 | 0.999487 | 1.012231 |
| 384x32 | 0.692453 | 1.008953 | 1.012235 |

Fine-mesh values are supplied package evidence; 48x4 was reproduced here. Package reports hybrid ~1.0115 at 576x48. Hybrid and MixedShear approach a similar limit near 1.012; hybrid's near-perfect 192x16 result is not its limiting value. DK trends toward an inappropriate low limit on this case rather than numerically diverging without bound.

2-003 OUT, exact repository 180x6 deck, central loaded edge node displacement from Python runs here:

| Variant | Displacement, in | Error vs previously stated shell target |
|---|---:|---:|
| DK | 0.453931958 | -0.147% |
| Hybrid | 0.495427839 | +8.981% |
| MixedShear | 0.498391497 | ~+9.63% |

Maintain BOTH shell and beam targets; do not swap the reference to improve apparent accuracy. Their exact values/provenance must be read from benchmark metadata. No multi-mesh 2-003 convergence study was completed here.

Twisted 2-004 n24 ratios (supplied package): Fz DK/hybrid/MixedShear = 0.50829/0.50840/0.50869; Fy = 0.35191/0.35214/0.35263. All remain poor. No evidence establishes faster convergence of one variant.

Supplied package static trade-offs: hemisphere n32 hybrid/MixedShear = 0.99219/1.00164; thin plate n8 = 0.99486/1.04089; coarse roof n2 = 1.15527/1.30526. These favor different candidates and are not all independently rerun here.

## 2-001 patch results — new Python runs

Repository distorted decks, SPCD enforced through partitioned solve. Metric is max absolute error over the nodal DOF vector divided by max absolute analytical DOF value; this mixes displacement/rotation units and is a reproduction metric, not a complete stress/energy certification.

| Patch | DK | Hybrid | MixedShear |
|---|---:|---:|---:|
| LC1 membrane | 7.1e-15 | 7.1e-15 | 7.1e-15 |
| LC2 bending | 1.5e-12 | 9.6e-13 | 1.4e-15 |
| LC3 constant shear | 2.9e-9 | 2.9e-9 | 0.0179313 |
| LC4 constant bending | 6.9e-17 | 1.0e-16 | 2.1e-16 |
| LC5 constant twist | 1.0e-16 | 6.9e-17 | 1.0e-16 |

MixedShear LC3 satisfies the free-DOF numerical equilibrium but misses the target field by 1.793%. In this deck ALL nodal bending rotations are restrained; do not call it an unrestricted constant-shear equilibrium patch. Audit reactions and recovered stresses separately. Hybrid reproduces all five tested nodal fields.

Earlier single-element `w=gamma*x, beta=0` energy ratios are diagnostic only. At rectangle 0.125x0.05, t=.1, hybrid total/exact=1.215053 comprises shear=1 and additional bending=.215053. Do not label it 21.5% excess shear energy or use that imposed state alone as a definitive patch acceptance test.

## Buckling and geometric stiffness

Diagnostic simply-supported square plate, t/a=.01, common prescribed global uniaxial compression, N transformed into each element local frame. Interior coordinate perturbations +/-0.30 cell size, seed 3; one random pattern only. Compare lambda to thin Kirchhoff 4*pi^2*D, not an exact thick-Mindlin target.

| Mesh | Distortion | DK | Hybrid | MixedShear |
|---|---:|---:|---:|---:|
| 8x8 | 0 | 1.021358 | 1.021357 | 0.995541 |
| 16x16 | 0 | 1.004883 | 1.004876 | 0.998410 |
| 8x8 | .30 | 1.025780 | 1.025779 | 0.996359 |
| 16x16 | .30 | 1.006640 | 1.006632 | 0.998977 |

Maximum first-eigenpair physical residual ~1.3e-11. An initial trial used incorrect rotational boundary placement and was rejected; exclude it. This diagnostic favors MixedShear but does not override the selected overall compromise.

2-017 actual repository decks, each candidate's own preload and inherited center-resultant Kg:

| Mesh | DK lambda | Hybrid lambda | MixedShear lambda |
|---|---:|---:|---:|
| 2x12 | 153.799396 | 153.799396 | 153.799396 |
| 4x24 | 133.317236 | 133.317236 | 133.317236 |

Maximum first-mode eigenpair residual 5.3e-12; preload residual 3.1e-14. In-plane case does not distinguish the bending/shear changes. Six eigenvalues were requested in this Python computation, but the reported residual acceptance was checked only for the first eigenpair; do not claim all-six-mode certification.

2-016c native revalidation is OPEN. Existing Python helper misses individual SPC cards and THRU expansion, and inherited Kg recovers center membrane resultants. Support the exact deck before running; check Gauss-point stress variation for bending preload. Do not use an incompletely constrained model or silently call center-resultant Kg native-equivalent.

## 2-008 dynamics — acceptable secondary trade-off per user

Python NSM-only translational lumped mass, PSHELL NSM=7.35e-7, no artificial rotational mass; inverse stiffness eigenproblem handles massless rotations. Same mass for all variants, total scalar mass .00042336.

| Mode | DK Hz | Hybrid Hz | MixedShear Hz |
|---|---:|---:|---:|
| 1 | 57.626111 | 57.509908 | 57.487919 |
| 2 | 140.926376 | 139.348698 | 139.078890 |
| 3 | 353.022608 | 350.377518 | 349.835420 |
| 4 | 450.395204 | 446.259834 | 445.485237 |
| 5 | 512.396871 | 504.397863 | 502.925098 |

Mass-weighted translational mode-vector MAC vs DK exceeds .99996 for modes 1–5. Native mass parity is NOT established. These are not independently certified absolute benchmark errors. User accepts modest higher-mode differences; retain them in reports but prioritize static consistency and convergence.

## Instructions for receiving Codex

1. Inspect AGENTS.md, current branch, dirty changes, prior mixed port, and binary provenance. Preserve user work. Keep an isolated research branch/worktree; never overwrite the published binary as a routine step.
2. Confirm whether native already implements precisely the selected hybrid. If it does, validate and document it rather than porting again. If it differs, report the exact difference before expanding implementation scope.
3. Preserve covariant Bs, consistent spin alpha=.03, effective Db/Ds, and inverse Jacobian. Keep An consistent in stiffness, bending recovery, and thermal loads. Prior native report retains legacy An when shared properties substitute artificial shear (`SHELL_T_MOD=Y`); verify that rule in source. Isotropic MAT1/PSHELL validation does not certify composites.
4. Reproduce 2-001 fields and then audit stresses/reactions with separate dimensional normalization. Add equilibrium-valid shear tests and several distortion seeds. Do not fit formulation parameters to benchmarks.
5. Complete 2-003 and twisted multi-mesh static curves before claiming their limits. Keep exact geometry, loads, BCs, observed DOFs and both 2-003 references.
6. Complete 2-016c bending/shear using exact SPC/LOAD handling. Compare common prescribed Kg and each candidate's recovered-preload Kg. Check stress frames, signs, quadrature, eigenmode identity and residuals for every requested mode.
7. Use DK/hybrid/MixedShear comparisons to retain transparent trade-offs; hybrid is the selected compromise, not a universal fix. No solver tolerance/default changes to conceal an eigenpair failure.
8. If native work is pursued in the user's Windows Codex session, require element matrix parity and full-response parity before accepting build results. This handoff itself makes no Fortran modifications.

## Inputs and reproducibility limits

Primary candidate package: `DSQK_2002_LC4_diagnosis 2710.zip` (user supplied), containing `DSQK_ConsistentSpin_MixedShear.py`, regression scripts and evidence. Baseline package: `DSQK_2002_Python_MYSTRAN_20261026.zip`; prior audit: `DSQK_Python_Shear_Audit_20261026(2).zip`.

Repository decks were fetched from branch `v18.00.a` at:
https://github.com/realbabilu/MYSTRAN/blob/v18.00.a/update/shell_benchmark/DAT/linear_shell_benchmark_DAT.zip

This handoff records the observed session outputs. Several new checks were run as temporary inline Python commands; a complete persisted rerun harness, immutable repository SHA, and raw output bundle were not produced. Receiving Codex must capture those for acceptance. Do not misrepresent this document as a fully reproducible release validation package.

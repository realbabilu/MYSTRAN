"""Reproducible Python DSQK patch audit. No native solver changes."""
from pathlib import Path
import io,json,sys,urllib.request,zipfile,hashlib
import numpy as np
from scipy.sparse.linalg import spsolve
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P/'python_reference'),str(P/'support')]
from assemble_reference import assemble
from build_suite import cards,grids
from DSQK_ConsistentSpin_CovShear_ShellElement import DSQK_ConsistentSpin_CovShear_ShellElement as DK
from DSQK_ConsistentSpin_CovShear_MixedElimination import DSQK_ConsistentSpin_CovShear_MixedElimination as HY
from DSQK_ConsistentSpin_CovShear_FullShearCandidates import MixedShearOnly as MS

def exact(x,y,sid):
    if sid==1:return np.array([.001*(x+.5*y),.001*(y+.5*x),0,0,0,0])
    if sid==2:return np.array([0,0,.0005*(x*x+x*y+y*y),.001*(y+.5*x),-.001*(x+.5*y),0])
    if sid==3:return np.array([0,0,.001*x,0,0,0])
    if sid==4:return np.array([0,0,.0005*x*x,0,-.001*x,0])
    return np.array([0,0,.001*x*y,.001*x,-.001*y,0])

out=P/'macneal_patch_audit';out.mkdir(exist_ok=True)
url='https://raw.githubusercontent.com/realbabilu/MYSTRAN/v18.00.a/update/shell_benchmark/DAT/linear_shell_benchmark_DAT.zip'
blob=urllib.request.urlopen(url,timeout=60).read();archive=zipfile.ZipFile(io.BytesIO(blob));rows=[]
for name in archive.namelist():
    if not(name.startswith('MYSTRAN/') and '2_001' in name and 'CQUAD4_DSQK/' in name):continue
    txt=archive.read(name).decode();cs=cards(txt);xyz=grids(txt)
    cases=[1,2] if '_mh_' in name else [3 if 'patchshear' in name else 4 if 'patchbending' in name else 5]
    deck=out/(name.split('/')[1]+'.dat');deck.write_text(txt)
    for cls in [DK,HY,MS]:
        K,F,free,ids,Q,els=assemble(deck,cls)
        for sid in cases:
            u=np.zeros(K.shape[0]);ue=np.concatenate([exact(*xyz[n][:2],sid) for n in ids])
            for c in cs:
                if c[0]=='SPCD' and int(c[1])==sid:u[6*ids.index(int(c[2]))+int(c[3])-1]=float(c[4])
            u[free]=spsolve(K[free,:][:,free],-(K@u)[free])
            err=(u-ue).reshape(-1,6);eng=np.zeros(4);analytical=0.;em=ek=es=0.;balance=np.zeros(6)
            for e,ns,C,ind in els.values():
                T=e._build_T_5to6();ul=T@C@u[ind];An=e._An();Hm,Hb,Hs=e._get_constitutive(float(np.mean(e.h)))
                R=np.array([e.t1[:2],e.t2[:2]])
                eps=np.array([[.001,.0005],[.0005,.001]]) if sid==1 else np.zeros((2,2))
                # beta = -grad(w); curvature uses engineering xy component.
                kap={2:np.array([[-.001,-.0005],[-.0005,-.001]]),4:np.diag([-.001,0]),5:np.array([[0,-.001],[-.001,0]])}.get(sid,np.zeros((2,2)))
                ep=R@eps@R.T;kp=e.t3[2]*(R@kap@R.T);ev=np.array([ep[0,0],ep[1,1],2*ep[0,1]]);kv=np.array([kp[0,0],kp[1,1],2*kp[0,1]]);sv=e.t3[2]*(R@np.array([.001,0])) if sid==3 else np.zeros(2)
                for a in [-1/np.sqrt(3),1/np.sqrt(3)]:
                    for b in [-1/np.sqrt(3),1/np.sqrt(3)]:
                        da=e._detJ(a,b);m=e._Bm(a,b)@ul;lo=e._Bbu(a,b)@ul;de=e._BbDelta(a,b)@An@ul;s=e._Bs(a,b)@ul
                        em=max(em,float(np.max(abs(m-ev))));ek=max(ek,float(np.max(abs(lo+de-kv))));es=max(es,float(np.max(abs(s-sv))))
                        eng+=.5*da*np.array([m@Hm@m,lo@Hb@lo,de@Hb@de,s@Hs@s]);analytical+=.5*da*(ev@Hm@ev+kv@Hb@kv+sv@Hs@sv)
            reactions=(K@u).reshape(-1,6)
            for j,n in enumerate(ids):balance[:3]+=reactions[j,:3];balance[3:]+=reactions[j,3:]+np.cross(xyz[n],reactions[j,:3])
            row=dict(deck=deck.name,variant=cls.__name__,case=sid,translation_max_abs=float(np.max(abs(err[:,:3]))),rotation_max_abs=float(np.max(abs(err[:,3:]))),membrane_strain_max_abs_error=em,curvature_max_abs_error=ek,shear_max_abs_error=es,energies=eng.tolist(),energy_ratio=float(eng.sum()/analytical),reaction_force_moment_balance_abs=balance.tolist(),free_residual_abs=float(np.linalg.norm((K@u)[free])))
            rows.append(row);print(json.dumps(row),flush=True)
(out/'results.json').write_text(json.dumps(dict(archive_url=url,archive_sha256=hashlib.sha256(blob).hexdigest(),results=rows),indent=2))

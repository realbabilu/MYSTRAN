"""
DSQK_ShellElement_RHR.py
========================
Discrete Shear Quadrilateral with Assumed Orthogonality (Katili), re-derived
directly from Katili, Abdel Wahab & Widyatmoko -- equations transcribed from
the source PDF (DSQK_maw_v0), Sections 2.4-2.11.

5 DOFs per node: u, v, w, Rx, Ry  (RHR).
Internal plate rotation convention (kept identical to the previous version
for compatibility with the rest of the codebase):
    beta_x = Ry ,  beta_y = -Rx
    gamma_x = beta_x + w,x = Ry + w,x
    gamma_y = beta_y + w,y = -Rx + w,y

Membrane   : standard bilinear Q4 (Eq. 15-18).
Bending    : l-order Bbu (Eq. 22, first block) + h-order BbDelta (Eq. 22,
             second block, quadratic P5..P8 bubble functions, Eq. 21) on the
             four mid-side rotation increments Delta_beta_sk.
             Delta_beta_sk eliminated via the *discrete-Kirchhoff* route:
             force the constant kinematic transverse shear strain along each
             side (Eq. 29) to zero  =>  An = -(3/2)*Au  (closed form, no
             matrix inversion needed). This is the lower-risk sibling of the
             paper's "mixed shear" route (Sec. 2.7.2, Eq. 31-34), which needs
             several additional 4x4 transformation matrices ([Hs],[Tj],[TD])
             that could not be transcribed from the source figure with full
             confidence -- for the thickness ratios used in this project's
             verification problems (thin-ish, h/L ~ 0.01-0.1) the two routes
             should not differ appreciably.
             kb = kbu + An^T kbDelta An   (Eq. 37, couple terms
             kbuDelta = kbDeltau dropped per the paper's "assumed
             orthogonality" condition).
Shear      : Bathe-Dvorkin / MITC4 assumed natural transverse shear strain
             (tying at the four side midpoints), a well-established,
             independently-verified locking cure.
Integration: 2x2 Gauss throughout (matches paper Eq. 41 note).
"""

import numpy as np
from core import Element


class DSQK_ShellElement_RHR(Element):
    def __init__(self, eid, nodes, E, nu, h, rho=None, alpha=0.0, is_fgm=False, p_index=0, scheme='1-6-1'):
        assert len(nodes) == 4, "DSQK_ShellElement_RHR requires 4 nodes"
        self.eid = eid
        self.nodes = nodes
        self.E = E
        self.nu = nu
        self.G = E / (2.0 * (1.0 + nu))
        self.h = np.ones(4) * h if np.isscalar(h) else np.array(h, dtype=float)
        self.rho = rho
        self.alpha = alpha  # coefficient of thermal expansion (isotropic)
        self.k_shear = 5.0 / 6.0
        self.is_fgm = is_fgm
        self.p_index = p_index
        # Populated externally by shell_utils_creases.update_nodal_normals_averaged()
        # (called once, after all elements are added, before solve_static()).
        # None => fall back to this element's own flat-facet normal only
        # (the original behaviour). See _compute_basis() for how it's used.
        self.nodal_normals = None
        self._compute_basis()

    @property
    def ndof_per_node(self):
        return 5  # u,v,w,Rx,Ry (RHR) -> expand_to_6dof adds Rz drilling

    # ------------------------------------------------------------------
    def _shape_functions(self, xi, eta):
        N = np.array([0.25*(1-xi)*(1-eta), 0.25*(1+xi)*(1-eta),
                      0.25*(1+xi)*(1+eta), 0.25*(1-xi)*(1+eta)])
        dNxi = np.array([-0.25*(1-eta), 0.25*(1-eta), 0.25*(1+eta), -0.25*(1+eta)])
        dNeta = np.array([-0.25*(1-xi), -0.25*(1+xi), 0.25*(1+xi), 0.25*(1-xi)])
        return N, dNxi, dNeta

    def _compute_basis(self):
        X = np.array([[n.x, n.y, n.z] for n in self.nodes])
        d1 = X[2] - X[0]
        d2 = X[1] - X[3]
        e1 = d1 / np.linalg.norm(d1)
        e2 = d2 / np.linalg.norm(d2)
        t1_flat = (e1 + e2) / np.linalg.norm(e1 + e2)
        t2_flat = (e1 - e2) / np.linalg.norm(e1 - e2)
        t3_flat = np.cross(t1_flat, t2_flat)
        t3_flat /= np.linalg.norm(t3_flat)

        if self.nodal_normals is not None:
            # Warp correction: use the *averaged* nodal normals (smoothed
            # across neighbouring elements by
            # shell_utils_creases.update_nodal_normals_averaged) instead of
            # this single element's own 2-diagonal flat normal. For a
            # smoothly-warped surface (twisted beam, shallow shell) this is
            # a much more representative "mean plane" normal than the
            # element's own corners alone; t1/t2 are then re-orthogonalized
            # against it (Gram-Schmidt) so the in-plane parametrization
            # stays consistent with the rest of the formulation. This is a
            # scoped improvement, not a full degenerated-shell (per-node
            # director) rewrite -- see class docstring.
            t3 = np.mean(self.nodal_normals, axis=0)
            n3 = np.linalg.norm(t3)
            t3 = t3 / n3 if n3 > 1e-12 else t3_flat
            if np.dot(t3, t3_flat) < 0:
                t3 = -t3  # keep consistent orientation with the flat normal
            # Gram-Schmidt: re-orthogonalize the flat t1 against the new t3
            t1 = t1_flat - np.dot(t1_flat, t3) * t3
            n1 = np.linalg.norm(t1)
            if n1 < 1e-8:
                # t1_flat nearly parallel to t3 (heavily warped/degenerate
                # case) -- fall back to t2_flat as the seed direction instead
                t1 = t2_flat - np.dot(t2_flat, t3) * t3
                n1 = np.linalg.norm(t1)
            t1 = t1 / n1
            t2 = np.cross(t3, t1)
        else:
            t1, t2, t3 = t1_flat, t2_flat, t3_flat

        self.t1, self.t2, self.t3 = t1, t2, t3

        # local planar (element x-y) coordinates of the 4 corner nodes
        self.Xl = np.stack([X @ self.t1, X @ self.t2], axis=1)  # (4,2)

        # sides 5,6,7,8 <-> (1-2),(2-3),(3-4),(4-1)  [Fig.6 of the paper]
        self.side_ij = [(0, 1), (1, 2), (2, 3), (3, 0)]
        Ck = np.zeros(4); Sk = np.zeros(4); Lk = np.zeros(4)
        for k, (i, j) in enumerate(self.side_ij):
            dx = self.Xl[j, 0] - self.Xl[i, 0]
            dy = self.Xl[j, 1] - self.Xl[i, 1]
            L = np.sqrt(dx*dx + dy*dy)
            Lk[k] = L
            Ck[k] = dx / L
            Sk[k] = dy / L
        self.Ck, self.Sk, self.Lk = Ck, Sk, Lk

    def _detJ_jac(self, xi, eta):
        Xl = self.Xl
        _, dNxi, dNeta = self._shape_functions(xi, eta)
        J11 = dNxi @ Xl[:, 0]; J12 = dNxi @ Xl[:, 1]
        J21 = dNeta @ Xl[:, 0]; J22 = dNeta @ Xl[:, 1]
        detJ = J11*J22 - J12*J21
        j11 = J22/detJ;  j12 = -J12/detJ
        j21 = -J21/detJ; j22 = J11/detJ
        return detJ, j11, j12, j21, j22

    def _detJ(self, xi, eta):
        detJ, *_ = self._detJ_jac(xi, eta)
        return detJ

    # ------------------------------------------------------------------
    # Membrane (Eq. 16) -- unchanged, this part was already correct
    def _Bm(self, xi, eta):
        N, dNxi, dNeta = self._shape_functions(xi, eta)
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        Bm = np.zeros((3, 20))
        for i in range(4):
            dNdx = j11*dNxi[i] + j12*dNeta[i]
            dNdy = j21*dNxi[i] + j22*dNeta[i]
            col = 5*i
            Bm[0, col]   = dNdx
            Bm[1, col+1] = dNdy
            Bm[2, col]   = dNdy
            Bm[2, col+1] = dNdx
        return Bm

    # ------------------------------------------------------------------
    # Geometric (stress) stiffness: standard von-Karman plate-buckling
    # form, using the gradient of the transverse (w) displacement field
    # only. G is (2x20): row0 = dNi/dx, row1 = dNi/dy at each node's w
    # column. kg = Int G^T [[Nxx,Nxy],[Nxy,Nyy]] G dA, added to the
    # linear stiffness for a linear buckling (eigenvalue) analysis:
    # (K + lambda*Kg) phi = 0.
    def _Gw(self, xi, eta):
        N, dNxi, dNeta = self._shape_functions(xi, eta)
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        G = np.zeros((2, 20))
        for i in range(4):
            dNdx = j11*dNxi[i] + j12*dNeta[i]
            dNdy = j21*dNxi[i] + j22*dNeta[i]
            col = 5*i
            G[0, col+2] = dNdx
            G[1, col+2] = dNdy
        return G

    def _Guv(self, xi, eta):
        """Same gradient pattern as _Gw, but for the in-plane u_local and
        v_local displacement components (needed for in-plane/Euler-type
        buckling -- e.g. a column swaying sideways within its own plane --
        as opposed to _Gw's out-of-plane plate-wrinkling buckling)."""
        N, dNxi, dNeta = self._shape_functions(xi, eta)
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        Gu = np.zeros((2, 20))
        Gv = np.zeros((2, 20))
        for i in range(4):
            dNdx = j11*dNxi[i] + j12*dNeta[i]
            dNdy = j21*dNxi[i] + j22*dNeta[i]
            col = 5*i
            Gu[0, col] = dNdx
            Gu[1, col] = dNdy
            Gv[0, col+1] = dNdx
            Gv[1, col+1] = dNdy
        return Gu, Gv

    def kg_local(self, Nxx, Nyy, Nxy):
        """Geometric stiffness for constant per-element membrane stress
        resultants (force/length) Nxx, Nyy, Nxy -- e.g. recovered from a
        reference static solve via _Bm and the membrane constitutive
        matrix. Positive = tension, negative = compression (standard
        shell/plate sign convention). Includes both the out-of-plane
        (Gw, plate/shell wrinkling) and in-plane (Gu, Gv, Euler-type
        sway/column) contributions -- the full Green-Lagrange geometric
        stiffness, not just the plate-buckling subset."""
        S = np.array([[Nxx, Nxy], [Nxy, Nyy]])
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]
        Kg = np.zeros((20, 20))
        for xi in gp:
            for eta in gp:
                dA = self._detJ(xi, eta)
                Gw = self._Gw(xi, eta)
                Gu, Gv = self._Guv(xi, eta)
                Kg += (Gu.T @ S @ Gu + Gv.T @ S @ Gv + Gw.T @ S @ Gw) * dA
        return Kg

    def membrane_stress_resultants(self, u_local_20):
        """Nxx, Nyy, Nxy (force/length) at the element center for a given
        LOCAL (u,v,w,Rx,Ry)x4 = 20-dof displacement vector. NOTE: does not
        subtract thermal strain -- use membrane_stress_resultants_thermal
        for the physical stress under a temperature load."""
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        Bm = self._Bm(0.0, 0.0)
        return Hm @ (Bm @ u_local_20)

    # ------------------------------------------------------------------
    # Thermal loading (temperature constant through the thickness -> pure
    # membrane thermal strain, no bending/curvature thermal effect).
    # eps_thermal = alpha*dT*[1,1,0]  (isotropic in-plane expansion, no
    # thermal shear strain).
    def f_thermal_local(self, dT):
        """Equivalent local (20-dof) nodal force vector for a uniform
        temperature rise dT, constant through the shell thickness."""
        if self.alpha == 0.0 or dT == 0.0:
            return np.zeros(20)
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        eps_th = self.alpha * dT * np.array([1.0, 1.0, 0.0])
        N_th = Hm @ eps_th  # thermal membrane stress resultant (force/length)
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]
        f = np.zeros(20)
        for xi in gp:
            for eta in gp:
                dA = self._detJ(xi, eta)
                Bm = self._Bm(xi, eta)
                f += Bm.T @ N_th * dA
        return f

    def membrane_stress_resultants_thermal(self, u_local_20, dT):
        """Physical Nxx, Nyy, Nxy at the element center, correctly
        subtracting the thermal strain: N = Hm @ (Bm@u - eps_thermal)."""
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        Bm = self._Bm(0.0, 0.0)
        eps_th = self.alpha * dT * np.array([1.0, 1.0, 0.0])
        return Hm @ (Bm @ u_local_20 - eps_th)

    # ------------------------------------------------------------------
    # Bending, l-order (Eq. 22 first block): kappa_x=d(beta_x)/dx,
    # kappa_y=d(beta_y)/dy, kappa_xy=d(beta_x)/dy+d(beta_y)/dx
    # with beta_x = Ry, beta_y = -Rx
    def _Bbu(self, xi, eta):
        N, dNxi, dNeta = self._shape_functions(xi, eta)
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        Bbu = np.zeros((3, 20))
        for i in range(4):
            dNdx = j11*dNxi[i] + j12*dNeta[i]
            dNdy = j21*dNxi[i] + j22*dNeta[i]
            col = 5*i
            Bbu[0, col+4] = dNdx    # kappa_x  from Ry
            Bbu[1, col+3] = -dNdy   # kappa_y  from Rx (beta_y=-Rx)
            Bbu[2, col+4] = dNdy    # kappa_xy from Ry
            Bbu[2, col+3] = -dNdx   # kappa_xy from Rx
        return Bbu

    # P5..P8 (Eq. 21) derivatives w.r.t. (xi,eta)
    def _Pk_derivs(self, xi, eta):
        dPxi = np.array([
            -xi*(1-eta),
             0.5*(1-eta**2),
            -xi*(1+eta),
            -0.5*(1-eta**2),
        ])
        dPeta = np.array([
            -0.5*(1-xi**2),
            -eta*(1+xi),
             0.5*(1-xi**2),
            -eta*(1-xi),
        ])
        return dPxi, dPeta

    # Bending, h-order (Eq. 22 second block / Eq. 20's Pk*Ck, Pk*Sk terms)
    def _BbDelta(self, xi, eta):
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        dPxi, dPeta = self._Pk_derivs(xi, eta)
        BbD = np.zeros((3, 4))
        for k in range(4):
            dPdx = j11*dPxi[k] + j12*dPeta[k]
            dPdy = j21*dPxi[k] + j22*dPeta[k]
            Ck, Sk = self.Ck[k], self.Sk[k]
            BbD[0, k] = Ck * dPdx
            BbD[1, k] = Sk * dPdy
            BbD[2, k] = Ck * dPdy + Sk * dPdx
        return BbD

    # --- v1 (kept for reference/regression comparison): discrete-Kirchhoff-
    # only route, i.e. setting the kinematic transverse shear strain
    # directly to zero and solving for Delta_beta_sk (Eq. 29 with the LHS
    # forced to 0). This is what this file used prior to transcribing the
    # source paper's own mixed-shear elimination (Eq. 31-34, below) --
    # kept here only so the two routes can be compared directly, e.g. in
    # a regression test. Not called anywhere by default anymore.
    def _An_discrete_kirchhoff_only(self):
        An = np.zeros((4, 20))
        for k, (i, j) in enumerate(self.side_ij):
            Lk, Ck, Sk = self.Lk[k], self.Ck[k], self.Sk[k]
            ci, cj = 5*i, 5*j
            An[k, ci+2] += 1.5/Lk
            An[k, cj+2] += -1.5/Lk
            An[k, ci+4] += -0.75*Ck   # Ry_i  (beta_x = Ry)
            An[k, cj+4] += -0.75*Ck   # Ry_j
            An[k, ci+3] += 0.75*Sk    # Rx_i  (beta_y = -Rx)
            An[k, cj+3] += 0.75*Sk    # Rx_j
        return An

    # --- v2 (current default): full mixed-shear-consistent elimination,
    # Eq. 27-34 of the source paper (DSQK_formulation.md Sec 2.5/6). This
    # is the ACTUAL DSQK method -- the source paper states its own
    # numerical study found this route "fully satisfied the kinematic
    # patch-tests for any L/h", unlike the v1 shortcut above.
    #
    # Eq. 29/30: kinematic (constant, per-side) transverse shear strain,
    # expressed in terms of the 20 physical DOFs (via [Au]) plus the 4
    # temporary bubble rotations (via [ADelta] = (2/3)*I4). The project's
    # own beta_x=Ry, beta_y=-Rx convention is substituted directly into
    # Eq. 29's beta_x,beta_y terms (this is a pure relabeling, same as
    # everywhere else in this project -- see DSQK_ShellElement_RHR_6DOF.py
    # / MIN4_PlateElement.py's own notes on the same convention choice).
    def _Au_and_ADelta(self):
        Au = np.zeros((4, 20))
        for k, (i, j) in enumerate(self.side_ij):
            Lk, Ck, Sk = self.Lk[k], self.Ck[k], self.Sk[k]
            ci, cj = 5*i, 5*j
            Au[k, ci+2] += -1.0/Lk    # w_i
            Au[k, cj+2] += 1.0/Lk     # w_j
            Au[k, ci+4] += 0.5*Ck     # Ry_i  (beta_x = Ry)
            Au[k, ci+3] += -0.5*Sk    # Rx_i  (beta_y = -Rx)
            Au[k, cj+4] += 0.5*Ck     # Ry_j
            Au[k, cj+3] += -0.5*Sk    # Rx_j
        ADelta = (2.0/3.0) * np.eye(4)
        return Au, ADelta

    # Eq. 31: the MIXED transverse shear field (2x4 at any (xi,eta)),
    # expressed purely in terms of the 4 temporary Delta_beta_sn unknowns
    # -- no dependence on the physical DOFs at all. [Hs] uses the
    # isotropic scalar bending/shear rigidity ratio Db/Ds; [tj] is built
    # from this element's own existing inverse-Jacobian entries
    # (j11,j12,j21,j22, from _detJ_jac -- same notation/definition as the
    # source paper's own j_ij, confirmed by matching variable names used
    # consistently across this author group's related papers); [TDelta]
    # uses the same per-side direction cosines (Ck,Sk) already computed
    # in _compute_basis.
    def _Bs_delta_mixed(self, xi, eta):
        h_avg = float(np.mean(self.h))
        Db = self.E * h_avg**3 / (12.0 * (1.0 - self.nu**2))
        Ds = self.k_shear * self.G * h_avg
        nu = self.nu
        Hs = (Db / Ds) * np.array([
            [1.0, (1.0-nu)/2.0, 0.0,          0.0,          0.0, (1.0+nu)/2.0],
            [0.0, 0.0,          (1.0+nu)/2.0, (1.0-nu)/2.0, 1.0, 0.0],
        ])
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        tj = np.array([
            [j11**2,   j12**2,   2*j11*j12],
            [j21**2,   j22**2,   2*j21*j22],
            [j11*j21,  j12*j22,  j11*j22 + j12*j21],
        ])
        Tj = np.zeros((6, 6))
        Tj[0:3, 0:3] = tj
        Tj[3:6, 3:6] = tj

        C5, C6, C7, C8 = self.Ck
        S5, S6, S7, S8 = self.Sk
        TDelta = np.array([
            [-C5*(1-eta), 0.0,         -C7*(1+eta), 0.0],
            [0.0,         -C6*(1+xi),  0.0,         -C8*(1-xi)],
            [C5*xi,       -C6*eta,     -C7*xi,      C8*eta],
            [-S5*(1-eta), 0.0,         -S7*(1+eta), 0.0],
            [0.0,         -S6*(1+xi),  0.0,         -S8*(1-xi)],
            [S5*xi,       -S6*eta,     -S7*xi,      S8*eta],
        ])
        return Hs @ Tj @ TDelta  # (2,4)

    # Eq. 32/33: collocate the mixed shear field at each side's own
    # midpoint (xi_k,eta_k) = (0,-1),(1,0),(0,1),(-1,0) for k=5,6,7,8,
    # projected onto that side's own (Ck,Sk) direction -> [AGamma] (4x4).
    # Eq. 34: equate the kinematic (Eq.30) and mixed (Eq.33) expressions
    # for the same 4 side-shear values and solve for Delta_beta_sn.
    def _An(self):
        Au, ADelta = self._Au_and_ADelta()
        tying_pts = [(0.0, -1.0), (1.0, 0.0), (0.0, 1.0), (-1.0, 0.0)]
        AGamma = np.zeros((4, 4))
        for k, (xi, eta) in enumerate(tying_pts):
            Bsd = self._Bs_delta_mixed(xi, eta)
            Ck, Sk = self.Ck[k], self.Sk[k]
            AGamma[k, :] = Ck * Bsd[0, :] + Sk * Bsd[1, :]
        return np.linalg.solve(AGamma - ADelta, Au)

    def _Bb(self, xi, eta, An=None):
        if An is None:
            An = self._An()
        return self._Bbu(xi, eta) + self._BbDelta(xi, eta) @ An

    # Aliases matching the naming convention used by other elements in this
    # codebase (e.g. problem_2_001_patchtest.py's post-processing routine).
    def _compute_Bm(self, xi, eta):
        return self._Bm(xi, eta)

    def _compute_Bb(self, xi, eta):
        return self._Bb(xi, eta)

    def _local_basis_at_point(self, xi, eta):
        # DSQK uses a single constant element basis (flat facet assumption)
        return self.t1, self.t2, self.t3

    # ------------------------------------------------------------------
    # Shear: Bathe-Dvorkin / MITC4 assumed natural transverse shear strain
    def _Bs_tying_row(self, xi_t, eta_t):
        N, dNxi, dNeta = self._shape_functions(xi_t, eta_t)
        _, j11, j12, j21, j22 = self._detJ_jac(xi_t, eta_t)
        Bs = np.zeros((2, 20))
        for i in range(4):
            dNdx = j11*dNxi[i] + j12*dNeta[i]
            dNdy = j21*dNxi[i] + j22*dNeta[i]
            col = 5*i
            Bs[0, col+2] = dNdx
            Bs[0, col+4] = N[i]     # gamma_x = w,x + Ry
            Bs[1, col+2] = dNdy
            Bs[1, col+3] = -N[i]    # gamma_y = w,y - Rx
        return Bs

    def _Bs(self, xi, eta):
        Bs_A = self._Bs_tying_row(0.0, -1.0)
        Bs_B = self._Bs_tying_row(0.0,  1.0)
        Bs_C = self._Bs_tying_row(-1.0, 0.0)
        Bs_D = self._Bs_tying_row(1.0,  0.0)
        Bs = np.zeros((2, 20))
        Bs[0, :] = 0.5*(1-eta)*Bs_A[0, :] + 0.5*(1+eta)*Bs_B[0, :]
        Bs[1, :] = 0.5*(1-xi)*Bs_C[1, :] + 0.5*(1+xi)*Bs_D[1, :]
        return Bs

    # ------------------------------------------------------------------
    def _get_constitutive(self, h_avg):
        factor = self.E / (1.0 - self.nu**2)
        Hm = factor * h_avg * np.array([[1, self.nu, 0], [self.nu, 1, 0], [0, 0, (1-self.nu)/2]])
        Hb = factor * (h_avg**3/12.0) * np.array([[1, self.nu, 0], [self.nu, 1, 0], [0, 0, (1-self.nu)/2]])
        Hs = self.k_shear * self.G * h_avg * np.eye(2)
        return Hm, Hb, Hs

    def k_local(self):
        # Recompute basis in case nodal_normals was set (or changed) after
        # __init__ by shell_utils_creases.update_nodal_normals_averaged().
        self._compute_basis()
        h_avg = float(np.mean(self.h))
        Hm, Hb, Hs = self._get_constitutive(h_avg)
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]

        Km = np.zeros((20, 20))
        Kbu = np.zeros((20, 20))
        KbD = np.zeros((4, 4))
        Ks = np.zeros((20, 20))

        for xi in gp:
            for eta in gp:
                dA = self._detJ(xi, eta)

                Bm = self._Bm(xi, eta)
                Km += Bm.T @ Hm @ Bm * dA

                Bbu = self._Bbu(xi, eta)
                Kbu += Bbu.T @ Hb @ Bbu * dA

                BbD = self._BbDelta(xi, eta)
                KbD += BbD.T @ Hb @ BbD * dA

                Bs = self._Bs(xi, eta)
                Ks += Bs.T @ Hs @ Bs * dA

        An = self._An()
        Kb = Kbu + An.T @ KbD @ An     # Eq. 37, couple terms dropped

        K_total = Km + Kb + Ks
        return K_total

    def T_matrix(self):
        """Rotate GLOBAL nodal DOF into this element's own LOCAL (t1,t2,t3)
        frame -- d_local = T @ d_global, matching every other element's
        T.T@Kl@T / T.T@Fl sandwich convention.

        BUGFIX: this used to be plain np.eye(20). That's only correct if
        t1=global-X and t2=global-Y for every element, which _compute_Bm/
        _compute_Bb/_compute_Bs implicitly require (their "u,v,Rx,Ry"
        columns are genuinely LOCAL (t1,t2)-relative quantities -- e.g.
        Bm[0,col]=dNdx*u assumes u is a scalar displacement ALONG t1, not
        a GLOBAL X-component). For a single axis-aligned test element
        that assumption happens to hold by coincidence (t1=X,t2=Y) --
        which is exactly why the old self-check below didn't catch this.
        It breaks completely on a real mesh where elements aren't
        axis-aligned (confirmed empirically: an annular mesh, where
        elements sit at every angle around the circle, gave wrong-signed
        results ~15x too large and broke the axisymmetric symmetry that
        every other element preserved to ~1e-16).

        Translation (u,v,w): a genuine 3-vector rotation,
            local = R @ global,  R = [t1; t2; t3] (rows).
        Rotation (Rx,Ry): only 2 GLOBAL rotation components are available
        at this element's 5-DOF/node slice of the model (no drilling
        theta_Z here), so the physical rotation vector is reconstructed
        as Omega = theta_X*X_hat + theta_Y*Y_hat (theta_Z implicitly 0 --
        the standard assumption for a true no-drilling shell fiber), and
        the LOCAL rotation about a director axis is that axis dotted with
        Omega (standard "rotation vector component along an axis"):
            Rx_local = Omega . t1 = theta_X*t1[0] + theta_Y*t1[1]
            Ry_local = Omega . t2 = theta_X*t2[0] + theta_Y*t2[1]
        (matches this element's own Rx=rotation-about-t1,
        Ry=rotation-about-t2, RHR convention used throughout _compute_Bb:
        kappa_x=Ry,x, kappa_y=-Rx,y).

        REMAINING LIMITATION (verified, not fixed -- shared by every
        5-DOF/node "no drilling" element, not specific to this one):
        reconstructing Rx,Ry from only 2 global rotation components
        (theta_X,theta_Y) implicitly assumes Omega has ZERO global-Z
        component. For a flat, coplanar mesh (t1,t2 always lying in one
        shared plane -- e.g. this file's own annular-plate battle test,
        battle_2_014.py) that assumption holds exactly for any pure-
        bending state, and this element now matches the other quad
        elements' accuracy there (verified: uz_inner within ~1% of the
        SAP2000 reference on the actual 28x32 mesh, axisymmetric symmetry
        preserved to ~1e-15). For a SINGLE element tilted arbitrarily in
        3D (tested in isolation, not as part of a flat mesh), Omega
        generally does NOT have zero global-Z component, and this 2-
        parameter global representation cannot capture that -- an
        isolated-element patch test with a fully general 3D orientation
        will show a real discrepancy that is NOT fixable within a 5-DOF/
        node formulation (would need a 3rd global rotation component,
        i.e. a 6-DOF/node drilling formulation, to represent exactly)."""
        t1, t2, t3 = self.t1, self.t2, self.t3
        R3 = np.array([t1, t2, t3])                       # 3x3
        R2 = np.array([[t1[0], t1[1]], [t2[0], t2[1]]])    # 2x2
        T = np.zeros((20, 20))
        for k in range(4):
            c = 5 * k
            T[c:c + 3, c:c + 3] = R3
            T[c + 3:c + 5, c + 3:c + 5] = R2
        return T

    def expand_to_6dof(self, K5):
        """5 DOF (u,v,w,Rx,Ry) -> 6 DOF (u,v,w,Rx,Ry,Rz) with a small
        drilling penalty stiffness about the element normal t3."""
        K6 = np.zeros((24, 24))
        for i in range(4):
            for j in range(4):
                blk = K5[5*i:5*i+5, 5*j:5*j+5]
                K6[6*i:6*i+3, 6*j:6*j+3] = blk[0:3, 0:3]
                K6[6*i+3:6*i+5, 6*j+3:6*j+5] = blk[3:5, 3:5]
                K6[6*i:6*i+3, 6*j+3:6*j+5] = blk[0:3, 3:5]
                K6[6*i+3:6*i+5, 6*j:6*j+3] = blk[3:5, 0:3]

        h_avg = float(np.mean(self.h))
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]
        area = sum(self._detJ(xi, eta) for xi in gp for eta in gp)
        drill_k = 0.03 * self.G * h_avg * area
        for i in range(4):
            K6[6*i+5, 6*i+5] += drill_k
        return K6

    def k_local_6dof(self):
        return self.expand_to_6dof(self.k_local())

    def m_local(self):
        if self.rho is None:
            return None
        Me = np.zeros((20, 20))
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]
        h_avg = float(np.mean(self.h))
        rho_h = self.rho * h_avg
        rho_I = self.rho * h_avg**3 / 12.0
        for xi in gp:
            for eta in gp:
                N, _, _ = self._shape_functions(xi, eta)
                dA = self._detJ(xi, eta)
                for i in range(4):
                    col = 5*i
                    Me[col, col] += rho_h * N[i] * dA
                    Me[col+1, col+1] += rho_h * N[i] * dA
                    Me[col+2, col+2] += rho_h * N[i] * dA
                    Me[col+3, col+3] += rho_I * N[i] * dA
                    Me[col+4, col+4] += rho_I * N[i] * dA
        return Me

    def f_local(self):
        return np.zeros(20)

    # -- thermal loading + stress/moment recovery ---------------------------
    #
    # Built in the SAME 20-DOF (5/node) space as k_local() / T_matrix(),
    # matching this element's ndof_per_node=5 -- these are the "official"
    # 20-dof methods used by the standard Element assembly path (T_matrix()
    # is the plain 20x20 identity here, so f_thermal_global == f_thermal_local
    # in practice, but the T_matrix() sandwich is kept for consistency with
    # every other element in this family, in case that ever changes).
    # NOT extended to the ad-hoc 6-dof/24-dof expand_to_6dof() path -- add
    # analogous wrappers there if something actually needs it.

    def _kappa_thermal(self, dT_grad):
        """kappa_th = alpha*dT_grad/h * [1,1,0] (isotropic, no thermal
        twist); dT_grad = T at local +t3 face minus T at local -t3 face.
        Same derivation as every other element in this family."""
        h_avg = float(np.mean(self.h))
        return (self.alpha * dT_grad / h_avg) * np.array([1.0, 1.0, 0.0])

    _GP = [-1.0 / np.sqrt(3.0), 1.0 / np.sqrt(3.0)]

    def f_thermal_local(self, dT):
        if self.alpha == 0.0 or dT == 0.0:
            return np.zeros(20)
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        N_th = Hm @ (self.alpha * dT * np.array([1.0, 1.0, 0.0]))
        f = np.zeros(20)
        for xi in self._GP:
            for eta in self._GP:
                Bm = self._Bm(xi, eta)
                f += Bm.T @ N_th * self._detJ(xi, eta)
        return f

    def f_thermal_global(self, dT):
        return self.T_matrix().T @ self.f_thermal_local(dT)

    def f_thermal_bending_local(self, dT_grad):
        if self.alpha == 0.0 or dT_grad == 0.0:
            return np.zeros(20)
        h_avg = float(np.mean(self.h))
        _, Hb, _ = self._get_constitutive(h_avg)
        M_th = Hb @ self._kappa_thermal(dT_grad)
        An = self._An()
        f = np.zeros(20)
        for xi in self._GP:
            for eta in self._GP:
                Bb = self._Bb(xi, eta, An=An)
                f += Bb.T @ M_th * self._detJ(xi, eta)
        return f

    def f_thermal_bending_global(self, dT_grad):
        return self.T_matrix().T @ self.f_thermal_bending_local(dT_grad)

    def membrane_stress_resultants(self, u_local_20, xi=0.0, eta=0.0):
        Bm = self._Bm(xi, eta)
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        return Hm @ (Bm @ np.asarray(u_local_20, dtype=float))

    def membrane_stress_resultants_from_global(self, u_global_20, xi=0.0, eta=0.0):
        return self.membrane_stress_resultants(
            self.T_matrix() @ np.asarray(u_global_20, dtype=float), xi, eta)

    def membrane_stress_resultants_thermal(self, u_local_20, dT, xi=0.0, eta=0.0):
        Bm = self._Bm(xi, eta)
        h_avg = float(np.mean(self.h))
        Hm, _, _ = self._get_constitutive(h_avg)
        eps_th = self.alpha * dT * np.array([1.0, 1.0, 0.0])
        return Hm @ (Bm @ np.asarray(u_local_20, dtype=float) - eps_th)

    def membrane_stress_resultants_thermal_from_global(self, u_global_20, dT, xi=0.0, eta=0.0):
        return self.membrane_stress_resultants_thermal(
            self.T_matrix() @ np.asarray(u_global_20, dtype=float), dT, xi, eta)

    def bending_stress_resultants(self, u_local_20, xi=0.0, eta=0.0):
        Bb = self._Bb(xi, eta)
        h_avg = float(np.mean(self.h))
        _, Hb, _ = self._get_constitutive(h_avg)
        return Hb @ (Bb @ np.asarray(u_local_20, dtype=float))

    def bending_stress_resultants_from_global(self, u_global_20, xi=0.0, eta=0.0):
        return self.bending_stress_resultants(
            self.T_matrix() @ np.asarray(u_global_20, dtype=float), xi, eta)

    def bending_stress_resultants_thermal(self, u_local_20, dT_grad, xi=0.0, eta=0.0):
        Bb = self._Bb(xi, eta)
        h_avg = float(np.mean(self.h))
        _, Hb, _ = self._get_constitutive(h_avg)
        kappa = Bb @ np.asarray(u_local_20, dtype=float)
        if dT_grad != 0.0 and self.alpha != 0.0:
            kappa = kappa - self._kappa_thermal(dT_grad)
        return Hb @ kappa

    def bending_stress_resultants_thermal_from_global(self, u_global_20, dT_grad, xi=0.0, eta=0.0):
        return self.bending_stress_resultants_thermal(
            self.T_matrix() @ np.asarray(u_global_20, dtype=float), dT_grad, xi, eta)


# ---------------------------------------------------------------------------
# Self-check
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from core import Node

    np.set_printoptions(precision=6, suppress=True)

    E, nu, h, alpha = 1000.0, 0.3, 1.0, 1.2e-5
    n1 = Node(1, 0.0, 0.0, 0.0)
    n2 = Node(2, 10.0, 0.0, 0.0)
    n3 = Node(3, 10.0, 8.0, 0.0)
    n4 = Node(4, 0.0, 8.0, 0.0)
    el = DSQK_ShellElement_RHR(1, [n1, n2, n3, n4], E, nu, h, alpha=alpha)
    coords = np.array([[0.0, 0.0], [10.0, 0.0], [10.0, 8.0], [0.0, 8.0]])

    print("=== 1) Rank check (20-dof, 5/node -- no drilling here at all) ===")
    K = el.k_local()
    print("K symmetric:", np.allclose(K, K.T))
    eigs = np.sort(np.linalg.eigvalsh(K))
    print("lowest 8 eigenvalues:", eigs[:8])
    n_zero = np.sum(np.abs(eigs) < 1e-8 * eigs[-1])
    print(f"exact-zero count: {n_zero} (expect 6: 3 translations + 2 bending")
    print("  tilts + 1 in-plane rotation -- with NO drilling DOF at all in")
    print("  this 5-dof/node representation, the in-plane rotation mode is")
    print("  captured cleanly by membrane alone, no fictitious-penalty")
    print("  competition to worry about the way there was for the 6-dof")
    print("  elements in battle_2_013)")

    print("\n=== 2) Membrane: pure thermal expansion -> zero stress ===")
    dT = 50.0
    u_local = np.zeros(20)
    for i, (x, y) in enumerate(coords):
        u_local[5 * i + 0] = alpha * dT * x
        u_local[5 * i + 1] = alpha * dT * y
    N = el.membrane_stress_resultants_thermal(u_local, dT)
    print(f"N = {N}  (expect ~[0,0,0])")
    print("PASS" if np.allclose(N, 0.0, atol=1e-8) else "FAIL")

    print("\n=== 3) Bending: pure through-thickness gradient -> zero moment ===")
    dT_grad = 100.0
    kap = el._kappa_thermal(dT_grad)
    # Bb = Bbu + BbDelta@An, and An involves the w (col+2) DOF (discrete-
    # Kirchhoff side constraint) -- same family as DKMT18/DKMT18SNORM, so a
    # "pure constant curvature" field needs the matching Kirchhoff w, not
    # rotations alone. Convention here: beta_x=Ry (kappa_x from Ry), beta_y=
    # -Rx (kappa_y from Rx negated) -- same RHR mapping used throughout.
    u_local2 = np.zeros(20)
    for i, (x, y) in enumerate(coords):
        u_local2[5 * i + 2] = -0.5 * kap[0] * x**2 - 0.5 * kap[1] * y**2  # w
        u_local2[5 * i + 3] = -kap[1] * y   # Rx  (kappa_y = -Rx,y = kap[1])
        u_local2[5 * i + 4] = kap[0] * x    # Ry  (kappa_x = Ry,x = kap[0])
    M = el.bending_stress_resultants_thermal(u_local2, dT_grad)
    print(f"M (rotation+Kirchhoff-w field) = {M}  (expect ~[0,0,0])")
    print("PASS" if np.allclose(M, 0.0, atol=1e-6) else "FAIL")
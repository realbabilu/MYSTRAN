# Latest Python reference matching experimental MYSTRAN DSQK drilling build.
# Native discrete-Kirchhoff elimination and corner-normal basis retained.
# Not equivalent to the supplied Python module's current mixed-shear default.
"""
DSQK_ShellElement_RHR_6DOF.py
- DSQK 5 DOF (u,v,w,Rx,Ry) + drilling Bergan/Hughes-Brezzi -> 6 DOF (u,v,w,Rx,Ry,Rz)
- RHR Mystran compatible
- K6 = expand(K5) + K_drill about t3
"""

import numpy as np
from core import Element
from DSQK_ShellElement_RHR import DSQK_ShellElement_RHR as DSQK5

class DSQK_ConsistentSpin_ShellElement(DSQK5):
    """
    Wraps the 5-DOF local (u,v,w,beta_x,beta_y) DSQK stiffness with a
    proper general local->global rotation transform, instead of assuming
    the element's local basis (t1,t2,t3) coincides with global (X,Y,Z).

    That naive assumption (u=Ux, v=Uy, w=Uz, beta_x=Ry, beta_y=-Rx) only
    holds for elements flat in the global X-Y plane. For elements lying in
    another plane (e.g. the X-Z plane, as in the cantilever verification
    mesh, where t1=X, t2=Z, t3=Y) it silently swaps which global rotation
    carries real bending stiffness and which is treated as drilling,
    producing a near-singular assembled stiffness matrix.

    Fix: build the actual 20x24 transform T from the computed t1,t2,t3 and
    use K24 = T^T @ K5_local @ T (standard local-to-global stiffness
    transform). This reduces exactly to the old hard-coded mapping when
    t1=X,t2=Y,t3=Z, and is correct for any other orientation too.
    """
    @property
    def ndof_per_node(self):
        return 6

    def _An(self):
        # Match the existing MYSTRAN DSQK elimination. The supplied base module
        # currently defaults to mixed-shear elimination instead.
        return self._An_discrete_kirchhoff_only()

    def _compute_basis(self):
        # Match native per-corner cross-product normals when no SNORM is supplied.
        original_normals = self.nodal_normals
        if original_normals is None:
            X = np.array([node.coords for node in self.nodes])
            normals = []
            for i in range(4):
                n = np.cross(X[(i+1)%4]-X[i], X[(i-1)%4]-X[i])
                length = np.linalg.norm(n)
                if length <= 1e-15:
                    raise ValueError("Degenerate DSQK corner")
                normals.append(n/length)
            self.nodal_normals = np.array(normals)
        try:
            return super()._compute_basis()
        finally:
            # Rebuild default corner normals if geometry is edited later.
            self.nodal_normals = original_normals

    def _build_T_5to6(self):
        # Local index 3 ("Rx" slot) is the variable used directly inside
        # _Bbu/_An/_Bs as "-beta_y" (i.e. beta_y = -Rx_local); local index 4
        # ("Ry" slot) is used directly as "beta_x". Since beta_x = rot.t2
        # and beta_y = -rot.t1, that means Rx_local = rot.t1 and
        # Ry_local = rot.t2 -- NOT the other way around (an earlier version
        # of this transform had rows 3 and 4 swapped/mis-signed, which
        # silently exchanged the roles of Rx and Ry and broke symmetry of
        # the bending response -- caught by a plain symmetric-tip-moment
        # test producing a spurious antisymmetric deflection).
        T = np.zeros((20, 24))
        for i in range(4):
            T[5*i+0, 6*i:6*i+3] = self.t1        # u_local = disp . t1
            T[5*i+1, 6*i:6*i+3] = self.t2        # v_local = disp . t2
            T[5*i+2, 6*i:6*i+3] = self.t3        # w_local = disp . t3
            T[5*i+3, 6*i+3:6*i+6] = self.t1      # Rx_local = rot . t1
            T[5*i+4, 6*i+3:6*i+6] = self.t2      # Ry_local = rot . t2
        return T

    def k_local(self):
        K5 = super().k_local()  # 20x20, in LOCAL (u,v,w,beta_x,beta_y) basis
        T = self._build_T_5to6()
        K24 = T.T @ K5 @ T

        # Drilling penalty about the actual normal t3 (the rotation
        # direction not captured by beta_x/beta_y above).
        h_avg = float(np.mean(self.h))
        gp = [-1.0/np.sqrt(3.0), 1.0/np.sqrt(3.0)]
        # Consistent-spin drilling at unchanged native alpha=0.03.
        for xi in gp:
            for eta in gp:
                N, dxi, deta = self._shape_functions(xi, eta)
                det, a, b, c, d = self._detJ_jac(xi, eta)
                dx, dy = a*dxi+b*deta, c*dxi+d*deta
                Bdr = np.zeros(24)
                for i in range(4):
                    Bdr[6*i:6*i+3] = -0.5*dy[i]*self.t1+0.5*dx[i]*self.t2
                    Bdr[6*i+3:6*i+6] = -N[i]*self.t3
                K24 += 0.03*self.G*h_avg*det*np.outer(Bdr, Bdr)
        return K24

    def T_matrix(self):
        return np.eye(24)

    def _compute_Bm(self, xi, eta):
        return super()._compute_Bm(xi, eta) @ self._build_T_5to6()

    def _compute_Bb(self, xi, eta):
        return super()._compute_Bb(xi, eta) @ self._build_T_5to6()

    def _local_basis_at_point(self, xi, eta):
        return self.t1, self.t2, self.t3

    def m_local(self):
        M5 = super().m_local()
        if M5 is None:
            return None
        T = self._build_T_5to6()
        return T.T @ M5 @ T

    def kg_local(self, Nxx, Nyy, Nxy):
        Kg5 = super().kg_local(Nxx, Nyy, Nxy)
        T = self._build_T_5to6()
        return T.T @ Kg5 @ T

    def k_geom_local(self, u_e):
        """Interface expected by core_sparse_buckling.py's solve_buckling:
        u_e is the element's GLOBAL 24-dof displacement vector (extracted
        directly via global_dof_indices()). Since T_matrix() is identity
        for this 6-dof wrapper (the local<->global rotation is handled
        internally via _build_T_5to6, same as k_local/m_local), this
        returns the geometric stiffness already in the same 24-dof GLOBAL
        space k_local() uses -- consistent with core_sparse_buckling.py's
        Kg_e_glob = T.T @ Kg_e @ T with T=I doing nothing further."""
        T = self._build_T_5to6()
        u_local_20 = T @ np.asarray(u_e, dtype=float)
        Nxx, Nyy, Nxy = super().membrane_stress_resultants(u_local_20)
        return self.kg_local(Nxx, Nyy, Nxy)

    def membrane_stress_resultants_from_global(self, u_global_24):
        T = self._build_T_5to6()
        u_local_20 = T @ u_global_24
        return super().membrane_stress_resultants(u_local_20)

    def f_thermal_global(self, dT):
        f5 = self.f_thermal_local(dT)
        T = self._build_T_5to6()
        return T.T @ f5

    def membrane_stress_resultants_thermal_from_global(self, u_global_24, dT):
        T = self._build_T_5to6()
        u_local_20 = T @ u_global_24
        return super().membrane_stress_resultants_thermal(u_local_20, dT)

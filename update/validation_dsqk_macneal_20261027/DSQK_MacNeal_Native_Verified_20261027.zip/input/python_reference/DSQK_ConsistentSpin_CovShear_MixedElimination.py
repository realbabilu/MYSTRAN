"""Research candidate: change only the bending elimination An to the supplied mixed-shear expression.
Covariant shear tying, consistent-spin alpha=0.03, bases and other operators remain inherited.
Validated here only for exact-DAT static 2-002 LC4; not a production replacement.
"""
from DSQK_ShellElement_RHR import DSQK_ShellElement_RHR as Base5
from DSQK_ConsistentSpin_CovShear_ShellElement import DSQK_ConsistentSpin_CovShear_ShellElement
class DSQK_ConsistentSpin_CovShear_MixedElimination(DSQK_ConsistentSpin_CovShear_ShellElement):
    def _An(self):
        return Base5._An(self)

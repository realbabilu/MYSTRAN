"""Exploratory shear operators for DSQK mixed-strain research.

These are diagnostic candidates only.  They expose whether the mixed
Delta-beta field should replace or augment the existing nodal tying operator.
"""
import numpy as np
from DSQK_ConsistentSpin_CovShear_MixedElimination import (
    DSQK_ConsistentSpin_CovShear_MixedElimination as Mixed,
)

class MixedShearOnly(Mixed):
    def _Bs(self, xi, eta):
        return self._Bs_delta_mixed(xi, eta) @ self._An()

class MixedShearAugmented(Mixed):
    def _Bs(self, xi, eta):
        return super()._Bs(xi, eta) + self._Bs_delta_mixed(xi, eta) @ self._An()

class MixedShearDeltaSubtracted(Mixed):
    def _Bs(self, xi, eta):
        return super()._Bs(xi, eta) - self._Bs_delta_mixed(xi, eta) @ self._An()

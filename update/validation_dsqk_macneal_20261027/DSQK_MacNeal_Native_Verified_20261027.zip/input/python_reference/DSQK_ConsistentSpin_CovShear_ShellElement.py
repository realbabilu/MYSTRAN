# Isolated Python candidate, 2026-10-24: consistent-spin DSQK + covariant (MITC4-style) assumed-shear tying.
# Everything except _Bs (and the shear recovery that calls it) is inherited UNCHANGED from
# DSQK_ConsistentSpin_ShellElement (native discrete-Kirchhoff elimination, per-corner normals, spin drilling alpha=0.03).
import numpy as np
from DSQK_ShellElement_RHR import DSQK_ShellElement_RHR as _Base5
from DSQK_ConsistentSpin_ShellElement import DSQK_ConsistentSpin_ShellElement


class CovariantShearMixin:
    """Ties the COVARIANT shear components gamma_xi at (0,+-1) and gamma_eta at (+-1,0), interpolates them
    linearly across the element, and maps to Cartesian with the Jacobian at the evaluation point.

    The package _Bs ties the CARTESIAN components (gamma_x from rows A,B; gamma_y from rows C,D). On a
    non-rectangular quad the bilinear w/beta interpolation error is not cancelled in a Cartesian component,
    so a shear-free field (e.g. constant curvature) produces spurious shear: measured 2.3x-3.6x the exact
    bending energy on a parallelogram / trapezoid / skew quad. Covariant tying uses only the tangential
    derivative along each edge, which the nodal data represent exactly, and is exact on all of those shapes.
    Rectangular elements are unchanged (verified bit-for-bit in test_covariant_shear.py)."""

    def _cov_row(self, xi_t, eta_t):
        Bt = _Base5._Bs_tying_row(self, xi_t, eta_t)            # Cartesian rows (gx, gy) at the tying point
        _, dNxi, dNeta = self._shape_functions(xi_t, eta_t)
        X = self.Xl
        x_xi, y_xi = dNxi @ X[:, 0], dNxi @ X[:, 1]
        x_eta, y_eta = dNeta @ X[:, 0], dNeta @ X[:, 1]
        return x_xi * Bt[0] + y_xi * Bt[1], x_eta * Bt[0] + y_eta * Bt[1]

    def _Bs(self, xi, eta):
        gxi_A, _ = self._cov_row(0.0, -1.0)
        gxi_B, _ = self._cov_row(0.0, 1.0)
        _, geta_C = self._cov_row(-1.0, 0.0)
        _, geta_D = self._cov_row(1.0, 0.0)
        gxi = 0.5 * (1 - eta) * gxi_A + 0.5 * (1 + eta) * gxi_B
        geta = 0.5 * (1 - xi) * geta_C + 0.5 * (1 + xi) * geta_D
        _, j11, j12, j21, j22 = self._detJ_jac(xi, eta)
        return np.vstack([j11 * gxi + j12 * geta, j21 * gxi + j22 * geta])


class DSQK_ConsistentSpin_CovShear_ShellElement(CovariantShearMixin, DSQK_ConsistentSpin_ShellElement):
    pass

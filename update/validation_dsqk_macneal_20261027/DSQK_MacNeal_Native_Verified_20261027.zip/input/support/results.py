"""Extract native solver F06 tables and evaluate fixed physical observables.

No displacement envelopes substitute for specified observation points. Values
with failed solves or missing native tables remain explicit missing rows.
"""
from pathlib import Path
import csv,json,math,re,struct
import numpy as np
from build_suite import ROOT,cards,grids,sha,fields

FLOAT=r'[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[EeDd][-+]?\d+)?'
def number(s):return float(s.rstrip('*').replace('D','E'))
def numeric(s):
    try:return [number(t) for t in s.split()]
    except ValueError:return None

def parse_f06(path,solver):
    text=path.read_text(errors='replace') if path.exists() else ''
    disp={};modes=[];stress={};forces={};subcase=1;state='';eid=None;laststress=None
    for line in text.splitlines():
        m=re.search(r'\bSUBCASE\s+(\d+)',line)
        if m:subcase=int(m[1])
        if 'D I S P L A C E M E N T' in line:state='disp';continue
        if 'S I N G L E - P O I N T   C O N S T R A I N T' in line:state='reaction';continue
        if 'R E A L   E I G E N V A L U E S' in line:state='eig';continue
        if 'E I G E N V E C T O R' in line:state='';continue
        if solver=='MYSTRAN' and 'E L E M E N T   S T R E S S E S' in line:state='stress';eid=None;continue
        if solver=='MYSTRAN' and 'E L E M E N T   E N G I N E E R I N G   F O R C E S' in line:state='force';continue
        if solver=='NASTRAN' and re.search(r'S T R E S S E S\s+I N',line):state='stress';eid=None;continue
        if solver=='NASTRAN' and re.search(r'F O R C E S\s+I N',line) and ('E L E M E N T S' in line):state='force';continue
        if any(s in line for s in ('S T R E S S E S   A T   G R I D','F O R C E S   A T   G R I D','S P C   F O R C E S','O L O A D','L O A D   V E C T O R','END OF JOB','>> LINK')):state='';continue
        tokens=line.split()
        if state in ('disp','reaction') and len(tokens)==8:
            try:
                nid=int(tokens[0]);coord=tokens[1]
                if coord!='G':int(coord)
                disp.setdefault(subcase,{})[nid]=[number(t) for t in tokens[2:]]
            except ValueError:pass
        elif state=='eig':
            nums=numeric(line)
            if nums and len(nums) in (3,7) and nums[0].is_integer() and nums[1].is_integer():
                modes.append(dict(mode=int(nums[0]),eigenvalue=nums[2],frequency=nums[4] if len(nums)==7 else None,subcase=subcase))
        elif state=='stress':
            try:
                if solver=='MYSTRAN':
                    # First fiber row: EID CENTER/Zn fiber sx sy txy ...
                    if len(tokens)>=11 and tokens[0].isdigit() and tokens[1] in ('CENTER','CEN/4','CEN/3'):
                        eid=int(tokens[0]);v=[number(t) for t in tokens[2:]]
                        stress.setdefault(subcase,[]).append([eid]+v[:4]);laststress=subcase
                    elif eid is not None and tokens and tokens[0]=='GRD' and len(tokens)>=11:
                        v=[number(t) for t in tokens[2:6]];stress.setdefault(subcase,[]).append([eid]+v)
                    elif eid is not None and len(tokens)>=8 and not tokens[0].isdigit():
                        v=[number(t) for t in tokens]
                        stress.setdefault(subcase,[]).append([eid]+v[:4])
                else:
                    # Nastran center fiber first row begins with carriage-control 0.
                    if len(tokens)==10 and tokens[0]=='0' and tokens[1].isdigit():
                        eid=int(tokens[1]);v=[number(t) for t in tokens[2:]]
                        stress.setdefault(subcase,[]).append([eid]+v[:4])
                    elif len(tokens)==11 and tokens[0]=='0' and tokens[1].isdigit() and tokens[2] in ('CEN/4','CEN/3'):
                        eid=int(tokens[1]);v=[number(t) for t in tokens[3:]]
                        stress.setdefault(subcase,[]).append([eid]+v[:4])
                    elif eid is not None and len(tokens)==9 and tokens[0].isdigit():
                        v=[number(t) for t in tokens[1:]];stress.setdefault(subcase,[]).append([eid]+v[:4])
                    elif eid is not None and len(tokens)==8:
                        v=[number(t) for t in tokens];stress.setdefault(subcase,[]).append([eid]+v[:4])
            except ValueError:pass
        elif state=='force':
            try:
                if len(tokens)==9 and tokens[0].isdigit():
                    forces.setdefault(subcase,[]).append([int(tokens[0])]+[number(t) for t in tokens[1:]])
                elif len(tokens)==10 and tokens[0].isdigit() and tokens[1] in ('CENTER','CEN/3','CEN/4'):
                    forces.setdefault(subcase,[]).append([int(tokens[0])]+[number(t) for t in tokens[2:]])
            except ValueError:pass
    # Repeated page headers can duplicate eig records; retain first native value.
    unique={}
    for m in modes:unique.setdefault((m['subcase'],m['mode']),m)
    return dict(displacements=disp,modes=list(unique.values()),stress=stress,forces=forces,text=text)

def kgg(path):
    """Read MYSTRAN dense real-double OUTPUT4 sequential Fortran records."""
    data=path.read_bytes();pos=0;records=[]
    while pos+8<=len(data):
        n=struct.unpack_from('<i',data,pos)[0]
        if n<=0 or pos+n+8>len(data):break
        assert struct.unpack_from('<i',data,pos+n+4)[0]==n
        records.append(data[pos+4:pos+n+4]);pos+=n+8
    for i,record in enumerate(records):
        if len(record)==24 and record[16:24].strip()==b'KGG':
            ncol,nrow,form,kind=struct.unpack_from('<4i',record)
            assert kind==2
            K=np.zeros((nrow,ncol))
            for rec in records[i+1:]:
                if len(rec)<12:continue
                col,row,nwords=struct.unpack_from('<3i',rec)
                if col>ncol:break
                v=np.frombuffer(rec[12:],dtype='<f8')
                K[row-1:row-1+len(v),col-1]=v
            return K
    raise ValueError('No supported KGG record')

def point_nodes(xyz,predicate):return [n for n,p in xyz.items() if predicate(p)]
def near(a,b):return abs(a-b)<=max(1,abs(b))*1e-6

def csi_published(row,quantity):
    """Secondary published thick-shell results, never primary denominators.

    Blank means no corresponding published model/observable is asserted.
    """
    g,c=row['group'],row['case'];values={};mesh=''
    if c=='s2k_2002a':
        values=dict(tip_UX=3e-5,tip_UZ=.1072,tip_UY=.4321,tip_abs_UY=.00224,tip_abs_UX=.000899,tip_RZ=.036);mesh='A-thick 6x1'
    elif g=='2003c':
        values=dict(tip_UY=.0884,tip_UZ=.4558,tip_UZ_alternative_shell_torsion=.4558);mesh='C-thick 90x3'
    elif c=='s2k_2004':values=dict(tip_UZ=.001760,tip_UY=.005402);mesh='Thick 12x2'
    elif g=='2006' and (row['quads'] or row['triangles']//4)==36:
        values=dict(free_edge_midpoint_UZ=-.3073,free_edge_midpoint_UZ_classical_alternative=-.3073);mesh='Thick source 6x6 quarter'
    elif g=='2007':values=dict(loaded_UX=.0927,loaded_UY=-.0927);mesh='Thick source 8x8 quarter'
    elif g=='2008c':
        values={f'frequency_mode_{i+1}':1/p for i,p in enumerate((.01739,.00712,.00285,.00223,.00197))};mesh='C-thick 40x40; f=1/T'
    elif g=='2009':values=dict(center_UZ=-.9250 if '009a' in c else -.1783);mesh='A-thick 50x50' if '009a' in c else 'B-thick 50x50'
    elif c=='s2k_2010b':values=dict(top_mean_Ur=.12387,top_mean_UZ=-.12387);mesh='B-thick 24x48'
    elif g in ('2012a','2012b'):
        values=dict(outer_edge_mean_UZ=-.00534 if g=='2012a' else -.00521);mesh='A-thick 6x96' if g=='2012a' else 'B-thick shear x1000 6x96'
    elif g=='2013':
        values=dict(joint8_UX=.000132,joint8_UY=.000066) if '013a' in c else dict(joint8_UX=0.,joint8_UY=0.,native_sigmaX_min=-733.33,native_sigmaX_max=-733.33,native_sigmaY_min=-733.33,native_sigmaY_max=-733.33)
        mesh='A-thick free expansion' if '013a' in c else 'B-thick restrained expansion'
    elif g=='2014':values=dict(inner_edge_mean_UZ=.01902,inner_edge_mean_tangent_rotation=.00347);mesh='B-thick 28x32'
    elif g=='2016c':values=dict(critical_edge_stress=.0425 if 'shear' in c else .1162);mesh='C-thick t=0.01, 64x64'
    elif g=='2017' and 'nx2_ny12' in c:values=dict(critical_load=127.22);mesh='Thick 2x12'
    return values.get(quantity),mesh if quantity in values else ''

def measures(row,data):
    text=(ROOT/row['deck']).read_text();xyz=grids(text);cs=cards(text);case=row['case'];group=row['group']
    disp=data['displacements'];out=[]
    def emit(quantity,value,ref,unit,lc=1,kind='independent',notes=''):
        out.append(dict(loadcase=lc,quantity=quantity,value=value,reference=ref,units=unit,reference_type=kind,notes=notes))
    def avg(lc,nodes,dof,absolute=False):
        d=disp.get(lc,{})
        if not nodes or not all(n in d for n in nodes):return None
        vals=[d[n][dof] for n in nodes]
        return float(np.mean(np.abs(vals) if absolute else vals))
    def result(q,lc,nodes,dof,ref,unit='in',absolute=False,kind='independent',notes=''):
        emit(q,avg(lc,nodes,dof,absolute),ref,unit,lc,kind,notes)
    if group=='2001':
        for lc,d in disp.items():
            expected={}
            for n,(x,y,z) in xyz.items():
                if '_mh_' in case:
                    v=[(x+.5*y)/1000,(y+.5*x)/1000,0,0,0,0] if lc==1 else [0,0,(x*x+x*y+y*y)/2000,(y+.5*x)/1000,-(x+.5*y)/1000,0]
                elif 'bending' in case:v=[0,0,.0005*x*x,0,-.001*x,0]
                elif 'twist' in case:v=[0,0,.001*x*y,.001*x,-.001*y,0]
                else:v=[0,0,.001*x,0,0,0]
                expected[n]=v
            # Original observation nodes are shared between families; centroid
            # interpolation of a quadratic field is not an exact FE nodal field.
            original=[n for n in d if n in expected and n<= (8 if '_mh_' in case else 9)]
            free=[n for n in original if n not in ({1,2,7,8} if '_mh_' in case else {1,2,3,4,6,7,8,9})]
            for ids,label in ((original,'all_original_nodes'),(free,'free_original_nodes')):
                for dims,name,unit in ((range(3),'translation','in'),(range(3,5),'rotation','rad')):
                    err=max((abs(d[n][i]-expected[n][i]) for n in ids for i in dims),default=None)
                    emit(f'{label}_{name}_max_abs_error',err,0.,unit,lc,'analytical field')
        # Rotation-invariant native fiber principal stresses avoid mixing
        # shell local frames. Full directional stress recovery is separate.
        for lc,st in data['stress'].items():
            principals=[]
            for eid,z,sx,sy,tau in st:
                p=(sx+sy)/2;radius=math.hypot((sx-sy)/2,tau);principals.extend([p+radius,p-radius])
            ref=(1733.333333333 if lc==1 else .866666666667) if '_mh_' in case else (.533333333333 if 'bending' in case else .4 if 'twist' in case else None)
            if ref is not None:emit('native_max_abs_fiber_principal_stress',max(map(abs,principals),default=None),ref,'psi',lc,'analytical field','Native reported element fiber samples; this invariant does not establish directional recovery or all-point uniformity.')
        if 'shear' in case:
            emit('native_max_transverse_shear_resultant',max((math.hypot(f[7],f[8]) for f in data['forces'].get(3,[])),default=None),1/3,'lb/in',3,'nominal continuum diagnostic','Nominal Mindlin Q=(5/6)*G*t*gamma. Stabilized/assumed-shear recovery may use a different operator; the reference Python shear-patch criterion checks the free-node displacement field.')
    elif group=='2002':
        zlo=min(p[2] for p in xyz.values());zhi=max(p[2] for p in xyz.values())
        tips=point_nodes(xyz,lambda p:near(p[0],6) and (near(p[2],zlo) or near(p[2],zhi)))
        # Physical tip corners only, including two-axis refinement.
        specs=[('tip_UX',0,3e-5,False),('tip_UZ',2,.1081,False),('tip_UY',1,.4321,False),('tip_abs_UY',1,.00341,True),('tip_abs_UX',0,.0009,True),('tip_RZ',5,.036,False)]
        for lc,(q,d,ref,ab) in enumerate(specs,1):result(q,lc,tips,d,ref,'rad' if d==5 else 'in',ab)
    elif group=='2003c':
        tips=point_nodes(xyz,lambda p:near(p[0],0) and (near(p[1],4.12) or near(p[1],4.32)))
        result('tip_UY',1,tips,1,.0886);result('tip_UZ',2,tips,2,.5004)
        result('tip_UZ_alternative_shell_torsion',2,tips,2,.4546,notes='Alternative reference from CSI discussion; primary 0.5004 remains reported.')
    elif group=='2004':
        xmax=max(p[0] for p in xyz.values());tips=point_nodes(xyz,lambda p:near(p[0],xmax))
        result('tip_UZ',2 if case.startswith('s2k') else 1,tips,2,.001749)
        result('tip_UY',1 if case.startswith('s2k') else 2,tips,1,.005429)
    elif group=='2005':
        p=max(xyz,key=lambda n:xyz[n][0]+xyz[n][1]);clamped='clamped' in case
        result('center_UZ_uniform',1,[p],2,-2.60 if clamped else -12.97)
        result('center_UZ_point',2,[p],2,-7.25 if clamped else -16.95)
    elif group=='2006':
        xmax=max(p[0] for p in xyz.values());ymax=max(p[1] for p in xyz.values())
        ids=point_nodes(xyz,lambda p:near(p[0],xmax) and near(p[1],ymax))
        result('free_edge_midpoint_UZ',1,ids,2,-.3086,'ft',notes='CSI Problem 2-006 revision 8 printed independent reference.')
        result('free_edge_midpoint_UZ_classical_alternative',1,ids,2,-.3024,'ft',kind='classical alternative',notes='Classical literature target shown separately; CSI printed -0.3086 remains primary.')
    elif group=='2007':
        # F06 translations are in GRID CD. The reference and force directions
        # here are basic XYZ, including the negative-Y loaded boundary node.
        bases={0:np.eye(3)};lines=text.splitlines()
        for i,line in enumerate(lines):
            c=fields(line)
            if c and c[0]=='CORD2R':
                A=np.array(list(map(float,c[3:6])));z=np.array(list(map(float,c[6:9])))-A;z/=np.linalg.norm(z)
                f=fields(lines[i+1]);x=np.array(list(map(float,f[1:4])))-A;x-=z*(x@z);x/=np.linalg.norm(x)
                bases[int(c[1])]=np.column_stack((x,np.cross(z,x),z))
        gridcd={int(c[1]):int(c[6] or 0) if len(c)>6 else 0 for c in cs if c[0]=='GRID'}
        for f in cs:
            if f[0]=='FORCE':
                dof=next(i for i in range(3) if float(f[5+i])!=0);nid=int(f[2]);raw=disp.get(1,{}).get(nid)
                value=float((bases[gridcd[nid]]@np.array(raw[:3]))[dof]) if raw is not None else None
                emit('loaded_U'+('X','Y','Z')[dof],value,.094 if float(f[5+dof])>0 else -.094,'ft',1,'independent','GRID CD translations transformed to basic XYZ before comparison.')
    elif group=='2008c':
        positive=[m for m in data['modes'] if m['eigenvalue']>0 and m['frequency'] is not None]
        for i,period in enumerate((.01723,.00704,.00281,.00219,.00193)):
            emit(f'frequency_mode_{i+1}',positive[i]['frequency'] if i<len(positive) else None,1/period,'Hz',1,'independent','Mode order comparison; no modal assurance criterion inferred.')
    elif group=='2009':
        center=min(xyz,key=lambda n:sum(v*v for v in xyz[n]));result('center_UZ',1,[center],2,-.9205 if '009a' in case else -.1782)
    elif group.startswith('2010'):
        # GRID CD is radial/tangential/up; native U1 is radial, U3 is axial.
        top=max(p[2] for p in xyz.values());ids=point_nodes(xyz,lambda p:near(p[2],top))
        result('top_mean_Ur',1,ids,0,.12414);result('top_mean_UZ',1,ids,2,-.12414)
        st=data['stress'].get(1,[])
        major=[(sx+sy)/2+math.hypot((sx-sy)/2,tau) for eid,z,sx,sy,tau in st]
        for fn,name in ((min,'min'),(max,'max')):emit('native_fiber_principal_max_'+name,fn(major) if major else None,60.,'ksi',1,'independent','Reported fiber samples, in-plane maximum principal stress; unreported corners are not inferred.')
    elif group in ('2012a','2012b'):
        ids=point_nodes(xyz,lambda p:near(math.hypot(p[0],p[1]),2.))
        result('outer_edge_mean_UZ',1,ids,2,-.00534 if group=='2012a' else -.00521)
    elif group=='2013':
        if '013a' in case:
            result('joint8_UX',1,[8],0,.000132);result('joint8_UY',1,[8],1,.000066)
        else:
            result('joint8_UX',1,[8],0,0.);result('joint8_UY',1,[8],1,0.)
            for axis,i in (('X',2),('Y',3)):
                vals=[s[i] for s in data['stress'].get(1,[])]
                emit('native_sigma'+axis+'_min',min(vals) if vals else None,-733.333333333,'psi')
                emit('native_sigma'+axis+'_max',max(vals) if vals else None,-733.333333333,'psi')
    elif group=='2014':
        rmin=min(math.hypot(p[0],p[1]) for p in xyz.values());ids=point_nodes(xyz,lambda p:near(math.hypot(p[0],p[1]),rmin))
        result('inner_edge_mean_UZ',1,ids,2,.01931)
        d=disp.get(1,{})
        value=float(np.mean([(-xyz[n][1]*d[n][3]+xyz[n][0]*d[n][4])/rmin for n in ids])) if ids and all(n in d for n in ids) else None
        emit('inner_edge_mean_tangent_rotation',value,.00352,'rad')
    elif group in ('2016c','2017'):
        positive=[m['eigenvalue'] for m in data['modes'] if m['eigenvalue']>0]
        value=min(positive) if positive else None
        if group=='2016c':
            emit('critical_edge_stress',None if value is None else value/.01,.0425 if 'shear' in case else .1165,'ksi',2,'independent','First positive buckling mode; sigma=lambda*qmax/t; qmax=1 kip/in, t=0.01 in. Shape identification is required for anomalous modes.')
            st=data['stress'].get(1,[])
            principal=[abs((sx+sy)/2+s*math.hypot((sx-sy)/2,tau)) for eid,z,sx,sy,tau in st for s in (-1,1)]
            emit('preload_max_abs_fiber_principal_stress',max(principal) if principal else None,100.,'ksi',1,'analytical prestress','Nominal edge traction 1 kip/in divided by t=0.01 in. For bending, exact 100 ksi is at the boundary; center-only recovery is explicitly below that limit.')
        else:emit('critical_load',value,127.91,'kip',2)
    elif group=='2050':
        f=next(f for f in cs if f[0]=='FORCE');result('loaded_UY',1,[int(f[2])],1,-1.8248e-5)
    elif group=='T':
        if 'rank' in case:
            if row.get('solver','MYSTRAN')=='MYSTRAN':
                try:
                    K=kgg((ROOT/row['deck']).with_suffix('.OU1'));Ksym=(K+K.T)/2
                    eig=np.linalg.eigvalsh(Ksym);tol=1e-9*max(abs(eig));nullity=int(np.sum(abs(eig)<=tol))
                    emit('KGG_nullity',nullity,6.,'DOF',1,'rigid body modes','rtol=1e-9 for native double-precision OUTPUT4 KGG.')
                    emit('KGG_negative_eigenvalues',int(np.sum(eig < -tol)),0.,'count',1,'positive semidefinite')
                    emit('KGG_relative_asymmetry',float(np.linalg.norm(K-K.T)/np.linalg.norm(K)),0.,'dimensionless',1,'matrix symmetry')
                except (ValueError,FileNotFoundError,AssertionError):emit('KGG_nullity',None,6.,'DOF',1,'rigid body modes')
            else:
                rankpath=(ROOT/row['deck']).with_name((ROOT/row['deck']).stem+'_rank.f06')
                try:
                    rankdata=parse_f06(rankpath,'NASTRAN');reaction=rankdata['displacements'];ids=sorted(xyz)
                    if 'END OF JOB' not in rankdata['text'] or 'FATAL MESSAGE' in rankdata['text']:raise ValueError('Rank solve failed')
                    # Nastran suppresses all-zero SPC-reaction rows; all requested
                    # unit-displacement subcases must nevertheless be present.
                    if not all(i in reaction for i in range(1,6*len(ids)+1)):raise ValueError('Missing unit case')
                    K=np.array([[reaction[col+1].get(node,[0.]*6)[d] for col in range(6*len(ids))] for node in ids for d in range(6)])
                    eig=np.linalg.eigvalsh((K+K.T)/2);tol=max(abs(eig))*1e-7
                    emit('KGG_nullity',int(np.sum(abs(eig)<=tol)),6.,'DOF',1,'rigid body modes','Stiffness reconstructed from native SPC reactions to each unit prescribed displacement. F06 printing precision limits tolerance to 1e-7.')
                    emit('KGG_negative_eigenvalues',int(np.sum(eig < -tol)),0.,'count',1,'positive semidefinite')
                    emit('KGG_relative_asymmetry',float(np.linalg.norm(K-K.T)/np.linalg.norm(K)),0.,'dimensionless',1,'matrix symmetry')
                except (KeyError,ValueError):emit('KGG_nullity',None,6.,'DOF',1,'rigid body modes','Native unit-displacement reaction reconstruction unavailable.')
        elif 'ss_plate' in case:
            center=min(xyz,key=lambda n:(xyz[n][0]-5)**2+(xyz[n][1]-5)**2)
            result('center_abs_UZ',1,[center],2,.00406*10**4/(2.1e6*.1**3/12),absolute=True)
        else:
            tips=point_nodes(xyz,lambda p:near(p[0],10))
            if 'moment' in case:
                result('tip_abs_UZ',1,tips,2,1000*100/(2*175),'in',True)
                result('tip_RY',1,tips,4,1000*10/175,'rad')
            elif 'axial' in case:result('tip_UX',1,tips,0,10/(2.1e6*.1))
            else:result('tip_UZ',1,tips,2,1000/(3*175)+10/((5/6)*1.05e6*.1))
    return out

def extract():
    audits={r['case']:r for r in json.loads((ROOT/'model_audit.json').read_text())}
    rows=json.loads((ROOT/'manifest.json').read_text())+json.loads((ROOT/'nastran_manifest.json').read_text());output=[];runs=[]
    for i,row in enumerate(rows):
        solver=row.get('solver','MYSTRAN');deck=ROOT/row['deck'];f06=deck.with_suffix('.F06' if solver=='MYSTRAN' else '.f06')
        data=parse_f06(f06,solver);text=data['text']
        version='18.0.A OCT 19 2026' if solver=='MYSTRAN' else 'Nastran'
        output_hash=sha(f06) if f06.exists() else ''
        if solver=='MYSTRAN':
            p=deck.parent/'run.json';meta=json.loads(p.read_text()) if p.exists() else {};status=meta.get('status','not_run')
            if meta.get('deck_sha256')!=row['sha256']:status='STALE_OUTPUT'
            errors=meta.get('errors',[])
            if status=='solver_error' and not errors:errors=[f'Process exit {meta.get("returncode")}; native output is incomplete. See console.log.']
        else:
            errors=re.findall(r'(?:\*{3}|\^{3})\s+(?:USER|SYSTEM)\s+FATAL\s+MESSAGE[^\n]*',text)
            status='completed' if 'END OF JOB' in text and not errors else 'solver_error' if text else 'not_run'
        run=dict(case=row['case'],solver=solver,solver_version=version,element=row['element'],formulation=row['formulation'],status=status,
            errors=' | '.join(errors),f06=str(f06.relative_to(ROOT)),sha256=row['sha256'],native_output_sha256=output_hash)
        runs.append(run)
        values=measures(dict(row,solver=solver),data)
        if row.get('active_loadcases'): values=[v for v in values if v['loadcase'] in row['active_loadcases']]
        if not values:values=[dict(loadcase='',quantity='native_table_missing',value=None,reference=None,units='',reference_type='',notes='No supported observable extracted')]
        for val in values:
            value,ref=val['value'],val['reference'];finite=value is not None and math.isfinite(value)
            csi,csi_mesh=csi_published(row,val['quantity'])
            val=dict(val);val.pop('value');val.pop('reference')
            numerical_status='MEASURED' if finite and status=='completed' else 'MISSING_NATIVE_TABLE' if value is None and status=='completed' else status.upper()
            output.append(dict(benchmark='2-'+row['group'][1:4] if row['group']!='T' else 'T',case=row['case'],solver=solver,
                solver_version=version,element=row['element'],formulation=row['formulation'],nodes=row['nodes'],parent_quads=row['quads'] or row['triangles']//4,
                **val,value=value if finite else '',reference=ref if ref is not None else '',
                ratio=value/ref if finite and ref else '',error_pct=100*abs(value-ref)/abs(ref) if finite and ref else '',
                absolute_error=abs(value-ref) if finite and ref is not None else '',status=numerical_status,
                csi_published_value=csi if csi is not None else '',csi_published_model=csi_mesh,
                error_vs_csi_pct=100*abs(value-csi)/abs(csi) if finite and csi else '',
                audit_status=audits[row['case']]['status'],native_output=str(f06.relative_to(ROOT)),deck_sha256=row['sha256'],native_output_sha256=output_hash))
        if (i+1)%300==0:print(f'Extracted {i+1}/{len(rows)} native files',flush=True)
    # Scalar CSV fields, blank missing values, no synthetic zero placeholders.
    with (ROOT/'comparison.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    with (ROOT/'run_status.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(runs[0]));w.writeheader();w.writerows(runs)
    (ROOT/'extraction.json').write_text(json.dumps(dict(metrics=len(output),runs=len(runs),measured=sum(r['status']=='MEASURED' for r in output)),indent=2))
    print(f'Wrote {len(output)} comparison rows from {len(runs)} runs')
if __name__=='__main__':extract()

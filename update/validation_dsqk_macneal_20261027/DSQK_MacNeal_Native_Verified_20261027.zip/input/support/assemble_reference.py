from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from core import Node
from build_suite import cards,fields,grids
def assemble(path,cls):
 text=Path(path).read_text();cs=cards(text);xyz=grids(text);ids=sorted(xyz);ix={n:i for i,n in enumerate(ids)};nodes={n:Node(n,*xyz[n]) for n in ids};bases={0:np.eye(3)};lines=text.splitlines()
 for i,line in enumerate(lines):
  f=fields(line)
  if f and f[0]=='CORD2R':
   assert int(f[2] or 0)==0
   A=np.array(list(map(float,f[3:6])));z=np.array(list(map(float,f[6:9])))-A;z/=np.linalg.norm(z);g=fields(lines[i+1]);x=np.array(list(map(float,g[1:4])))-A;x-=z*(z@x);x/=np.linalg.norm(x);bases[int(f[1])]=np.column_stack([x,np.cross(z,x),z])
 Q={}
 for f in cs:
  if f[0]=='GRID':
   assert int(f[2] or 0)==0
   q=np.zeros((6,6));b=bases[int(f[6] or 0)] if len(f)>6 else bases[0];q[:3,:3]=b;q[3:,3:]=b;Q[int(f[1])]=q
 mat=next(c for c in cs if c[0]=='MAT1');prop=next(c for c in cs if c[0]=='PSHELL');E=float(mat[2].replace('.+','.e+').replace('.-','.e-'));nu=float(mat[4]);h=float(prop[3]);rr=[];cc=[];vv=[];els={}
 for c in cs:
  if c[0] not in ('CTRIA3','CTRIAR','CQUAD4'):continue
  ns=list(map(int,c[3:7 if c[0]=='CQUAD4' else 6]));nd=6*len(ns);e=cls(int(c[1]),[nodes[n] for n in ns],E,nu,h);C=np.zeros((nd,nd));d=np.array([6*ix[n]+j for n in ns for j in range(6)])
  for i,n in enumerate(ns):C[6*i:6*i+6,6*i:6*i+6]=Q[n]
  K=C.T@e.k_global()@C;rr.extend(np.repeat(d,nd));cc.extend(np.tile(d,nd));vv.extend(K.ravel());els[int(c[1])]=(e,ns,C,d)
 n=6*len(ids);K=coo_matrix((vv,(rr,cc)),shape=(n,n)).tocsr();forces={};fixed=set()
 for c in cs:
  if c[0]=='FORCE':
   sid=int(c[1]);nid=int(c[2]);v=bases[int(c[3] or 0)]@(float(c[4])*np.array(list(map(float,c[5:8]))));forces.setdefault(sid,np.zeros(n))[6*ix[nid]:6*ix[nid]+3]+=Q[nid][:3,:3].T@v
  if c[0]=='MOMENT':
   sid=int(c[1]);nid=int(c[2]);v=bases[int(c[3] or 0)]@(float(c[4])*np.array(list(map(float,c[5:8]))));forces.setdefault(sid,np.zeros(n))[6*ix[nid]+3:6*ix[nid]+6]+=Q[nid][:3,:3].T@v
  if c[0]=='PLOAD4':
   sid=int(c[1]);eid=int(c[2]);p=float(c[3]);assert all(not v or float(v)==p for v in c[4:7])
   e,ns,C,d=els[eid];fg=np.zeros(18)
   for i in range(3):fg[6*i:6*i+3]=p*e.A/3*e.ez
   forces.setdefault(sid,np.zeros(n))[d]+=C.T@fg
  if c[0]=='SPC1':
   assert 'THRU' not in c
   for node in map(int,c[3:]):
    for comp in c[2]:fixed.add(6*ix[node]+int(comp)-1)
 free=np.setdiff1d(np.arange(n),sorted(fixed));return K,forces,free,ids,Q,els

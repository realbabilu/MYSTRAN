"""Build isolated, formulation-neutral MYSTRAN shell benchmark decks.

Only the element card and formulation selector change within a case.
Original inputs are retained with SHA256 provenance. No source tree edits.
"""
from pathlib import Path
import csv, hashlib, json, re, shutil, math

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent
FORMS = [("CQUADR", "QUADRTYP", f) for f in
         ("SIMO", "DKMQ24", "DKM24EA", "DKM24AU", "Q4EASANS", "MBP1C0", "MITC4PD", "Q4RS")]
FORMS += [("CQUAD4", "QUAD4TYP", f) for f in
          ("MIN4", "MIN4T", "MITC4", "MITC4+", "DSQK", "DKMQ20", "SIMO")]
TRI_FORMS = [('CTRIA3','TRIA3TYP',f) for f in ('MIN3','MITC3+','T3FF','DSG3')]
TRI_FORMS += [('CTRIAR','TRIARTYP',f) for f in ('DKMT18','T3FFD','KMITC3+')]
SELECTORS=('QUADRTYP','QUAD4TYP','TRIA3TYP','TRIARTYP')

def real(x):
    s=format(float(x or 0),'.10g')
    return s if any(c in s.lower() for c in '.e') else s+'.'

def normalize_reals(text):
    # MYSTRAN requires decimal/exponent markers; free fields have a 16-char limit.
    positions={'GRID':(3,4,5),'MAT1':tuple(range(2,12)), 'PSHELL':(3,5,7,8,9,10),
        'FORCE':(4,5,6,7),'MOMENT':(4,5,6,7),'PLOAD4':(3,4,5,6,9,10,11),
        'TEMPP1':(3,4),'TEMP':(3,5,7),'SPCD':(4,7),'PELAS':(2,3,4),'CONM2':(4,5,6,7),
        'PBAR':tuple(range(3,19)), 'CBAR':(5,6,7),'CELAS2':(2,)}
    out=[]; bulk=False;seen_params={}
    for line in text.splitlines():
        if line.strip()=='BEGIN BULK':
            bulk=True;out.append(line);continue
        if bulk and line.strip() and not line.lstrip().startswith('$'):
            f=fields(line)
            for i in positions.get(f[0],()):
                if i<len(f) and f[i]: f[i]=real(f[i])
            if f[0]=='PARAM':
                if f[1] in seen_params:
                    if f!=seen_params[f[1]]:raise ValueError(f'Conflicting parameter: {f[1]}')
                    continue
                seen_params[f[1]]=f
            line=','.join(f)
        out.append(line)
    return '\n'.join(out)+'\n'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def fields(line):
    s = line.split('$')[0].rstrip()
    return [x.strip() for x in s.split(',')] if ',' in s else [s[i:i+8].strip() for i in range(0,len(s),8)]

def cards(text):
    return [fields(s) for s in text.split('BEGIN BULK',1)[1].splitlines()
            if s.strip() and not s.lstrip().startswith('$')]

def grids(text):
    return {int(f[1]): tuple(float(x or 0) for x in f[3:6]) for f in cards(text) if f[0]=='GRID'}

def canonical(text):
    """Comparison digest excludes formulation selectors and shell-card spelling."""
    out=[]
    for line in text.splitlines():
        f=fields(line)
        if f and f[0]=='PARAM' and len(f)>1 and f[1] in SELECTORS: continue
        if f and f[0] in ('CQUADR','CQUAD4'): f[0]='QUAD'
        if f and f[0] in ('CTRIA3','CTRIAR'): f[0]='TRI'
        out.append(','.join(f))
    return hashlib.sha256('\n'.join(out).encode()).hexdigest()

def variant(text, element, param, value):
    out=[]
    for line in text.splitlines():
        f=fields(line)
        if f and f[0]=='PARAM' and len(f)>1 and f[1] in SELECTORS: continue
        if f and f[0] in ('CQUADR','CQUAD4','CTRIA3','CTRIAR'):
            f[0]=element; line=','.join(f)
        out.append(line)
        if line.strip()=='BEGIN BULK': out.append(f'PARAM,{param},{value}')
    return '\n'.join(out)+'\n'

def triangulate(text):
    """Four planar children per quad, sharing one arithmetic centroid.

    Preserve nodal/edge loads. Transfer face pressure and thermal gradients to
    children. No projection of curved facets and no inherited element-ID alias.
    """
    xyz=grids(text); cs=cards(text); shells=[f for f in cs if f[0] in ('CQUADR','CQUAD4')]
    next_node=max(xyz)+1
    next_eid=max(int(f[1]) for f in cs if f[0] in ('CQUADR','CQUAD4','CBAR','CELAS1','CONM2'))+1
    mapping={}; inserts=[];tributary={};area_total=0.
    for f in shells:
        ns=list(map(int,f[3:7])); center=next_node; next_node+=1
        p=tuple(sum(xyz[i][a] for i in ns)/4 for a in range(3)); xyz[center]=p
        inserts.append(','.join(['GRID',str(center),'']+[real(x) for x in p]))
        children=[]
        for j in range(4):
            eid=next_eid; next_eid+=1; children.append(eid)
            extra=[f[7]] if len(f)>7 else []
            inserts.append(','.join(['CTRIA3',str(eid),f[2],str(ns[j]),str(ns[(j+1)%4]),str(center)]+extra))
            a,b,c=xyz[ns[j]],xyz[ns[(j+1)%4]],p
            u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
            cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
            area=math.sqrt(sum(x*x for x in cross))/2;area_total+=area
            for node in (ns[j],ns[(j+1)%4],center):tributary[node]=tributary.get(node,0)+area/3
        mapping[int(f[1])]=children
    springs=[f for f in cs if f[0]=='CELAS1']; foundation=len(springs)>10
    if foundation:
        props={f[1]:float(f[2]) for f in cs if f[0]=='PELAS'}
        k=sum(props[f[2]] for f in springs)/area_total
        for i,(node,area) in enumerate(sorted(tributary.items()),10000000):
            inserts.extend([f'PELAS,{i},{real(k*area)}',f'CELAS1,{i},{i},{node},3'])
    out=[]
    for line in text.splitlines():
        f=fields(line)
        if f and f[0] in ('CQUADR','CQUAD4'): continue
        if foundation and f and f[0] in ('CELAS1','PELAS'):continue
        if f and f[0] in ('PLOAD4','TEMPP1') and int(f[2]) in mapping:
            for j,eid in enumerate(mapping[int(f[2])]):
                g=f.copy();g[2]=str(eid)
                if f[0]=='PLOAD4':
                    pressure=[float(f[i]) if i<len(f) and f[i] else float(f[3]) for i in range(3,7)]
                    while len(g)<7:g.append('')
                    g[3:7]=[real(pressure[j]),real(pressure[(j+1)%4]),real(sum(pressure)/4),'']
                out.append(','.join(g))
            continue
        if line.strip()=='ENDDATA': out+=inserts
        out.append(line)
    result='\n'.join(out)+'\n'
    # Pressure-cylinder kinematics must hold at new centroid nodes too.
    if 'PDF_CYLINDER_KINEMATICS' in text:
        result=cylinder_kinematics(result)
    return result

def cylinder_kinematics(text):
    xyz=grids(text); output=[]
    for line in text.splitlines():
        f=fields(line)
        if f and f[0] in ('SPC1','SPC','CORD2R','+'): continue
        if f and f[0]=='GRID':
            while len(f)<7:f.append('')
            f[6]=str(100000+int(f[1]));line=','.join(f)
        if line.strip()=='ENDDATA':
            for nid,(x,y,z) in xyz.items():
                r=math.hypot(x,y); cid=100000+nid
                output.extend([f'CORD2R,{cid},0,0.,0.,0.,0.,0.,1.',f'+,{real(x/r)},{real(y/r)},0.',
                               f'SPC1,1,{"23" if abs(z)<1e-8 else "2"},{nid}'])
        output.append(line)
    return '\n'.join(output)+'\n'

def cylinder_model(text):
    head='SOL 101\nCEND\nTITLE = PRESSURE CYLINDER - PDF KINEMATICS\nECHO = NONE\nSPC = 1\nLOAD = 1\nDISPLACEMENT = ALL\nSTRESS = ALL\nFORCE = ALL\nBEGIN BULK\n$ PDF_CYLINDER_KINEMATICS\nMAT1,1,29000.,,0.3\nPSHELL,1,1,1.,1,,1\n'
    keep=[]; pressure=[]
    for f in cards(text):
        if f[0] in ('GRID','CQUAD4','CQUADR'):
            keep.append(','.join(f))
            if f[0]!='GRID': pressure.append(f'PLOAD4,1,{f[1]},1.')
    return cylinder_kinematics(head+'\n'.join(keep+pressure+['ENDDATA'])+'\n')

def s2k_geometry(path):
    t=tables(path);out=['SOL 101','CEND','BEGIN BULK']
    for j in t['JOINT COORDINATES']:
        out.append(','.join(['GRID',j['Joint'],'']+[real(j[k]) for k in ('GlobalX','GlobalY','GlobalZ')]))
    for a in t['CONNECTIVITY - AREA']:
        out.append(','.join(['CQUADR',a['Area'],'1']+[a[f'Joint{i}'] for i in range(1,5)]))
    return '\n'.join(out+['ENDDATA'])+'\n'

def edge_tractions(text):
    """Replace dummy-beam global PLOAD1 tractions by consistent shell-edge forces."""
    xyz=grids(text);cs=cards(text);bars={int(f[1]):f for f in cs if f[0]=='CBAR'}
    output=[];forces={};spring_pid=990001
    for line in text.splitlines():
        f=fields(line)
        if f and (f[0] in ('CBAR','PBAR') or (f[0]=='MAT1' and f[1]=='2')):continue
        if f and f[0]=='CELAS2':
            # Source spring is UX at a node on y=0: it cannot remove rotation
            # about the UX/UY pin at node 1. Use a compatible transverse gauge.
            output.append(f'SPC1,1,2,{f[3]}');continue
        if f and f[0]=='SPC' and f[3]=='6':
            # An independent drilling constraint is not a physical in-plane
            # rotation gauge for every shell family.
            continue
        if f and f[0]=='PLOAD1':
            bar=bars[int(f[2])];a,b=int(bar[3]),int(bar[4]); L=math.dist(xyz[a],xyz[b])
            direction={'FX':0,'FY':1,'FZ':2}[f[3]]
            assert f[4]=='FR' and float(f[5])==0 and float(f[7])==1
            q0,q1=float(f[6]),float(f[8])
            for nid,val in ((a,L*(2*q0+q1)/6),(b,L*(q0+2*q1)/6)):
                key=(int(f[1]),nid,direction);forces[key]=forces.get(key,0)+val
            continue
        if line.strip()=='ENDDATA':
            for (sid,nid,d),val in sorted(forces.items()):
                if val:
                    vector=['0.','0.','0.'];vector[d]='1.'
                    output.append(','.join(['FORCE',str(sid),str(nid),'0',real(val)]+vector))
        output.append(line)
    return '\n'.join(output)+'\n'

def tables(path):
    """Parse S2K table rows, including continuation records ending in underscore."""
    result={}; table=None; pending=''
    for line in Path(path).read_text(errors='replace').splitlines():
        m=re.match(r'TABLE:\s+"(.+)"',line)
        if m: table=m[1]; result[table]=[]; continue
        if not table or not line.strip(): continue
        line=pending+' '+line.strip(); pending=''
        if line.endswith('_'): pending=line[:-1]; continue
        row={k:(v[1:-1] if v.startswith('"') else v) for k,v in
             re.findall(r'(\w+)=("[^"]*"|[^\s]+)',line)}
        if row: result[table].append(row)
    return result

def s2k_curved(path):
    """Exact c/d joint/connectivity/load/support import; no remeshing assumptions."""
    t=tables(path); sec=t['AREA SECTION PROPERTIES'][0]
    mat=next(m for m in t['MATERIAL PROPERTIES 02 - BASIC MECHANICAL PROPERTIES'] if m['Material']==sec['Material'])
    loads=t['JOINT LOADS - FORCE']; pats=sorted(set(x['LoadPat'] for x in loads))
    out=['SOL 101','CEND','ECHO = NONE']
    for i,p in enumerate(pats,1): out += [f'SUBCASE {i}',f' LABEL = {p}',' SPC = 1',f' LOAD = {i}',' DISPLACEMENT = ALL']
    out+=['BEGIN BULK',f"MAT1,1,{mat['E1']},,{mat['U12']}",f"PSHELL,1,1,{sec['Thickness']},1,,1"]
    for j in t['JOINT COORDINATES']:
        out.append(f"GRID,{j['Joint']},,{j['GlobalX']},{j['GlobalY']},{j['GlobalZ']}")
    for a in t['CONNECTIVITY - AREA']:
        assert a['NumJoints']=='4'
        out.append(','.join(['CQUADR',a['Area'],'1']+[a[f'Joint{i}'] for i in range(1,5)]))
    for j in t['JOINT RESTRAINT ASSIGNMENTS']:
        dofs=''.join(str(i) for i,k in enumerate(('U1','U2','U3','R1','R2','R3'),1) if j.get(k)=='Yes')
        if dofs: out.append(f"SPC1,1,{dofs},{j['Joint']}")
    for j in loads:
        assert j.get('CoordSys','GLOBAL')=='GLOBAL'
        sid=pats.index(j['LoadPat'])+1
        for prefix,card in [('F','FORCE'),('M','MOMENT')]:
            for i in range(1,4):
                v=float(j.get(f'{prefix}{i}',0))
                if v:
                    direction=['0.','0.','0.']; direction[i-1]='1.'
                    out.append(','.join([card,str(sid),j['Joint'],'0',str(v)]+direction))
    return '\n'.join(out+['ENDDATA'])+'\n'

SPECS = [
 ('2001','D:/18a/python/linear/working_mystran_2_001','*cquadr_simo.dat'),
 ('2002','D:/18a/python/linear/working_mystran_2_002','*cquadr_simo.dat'),
 ('2003_legacy','D:/18a/python/linear/working_mystran','prob_2_003_*cquadr_simo.dat'),
 ('2004','D:/18a/python/linear/working_mystran_2_004','*cquadr_simo.dat'),
 ('2005','D:/18a/bending_only/Shell/gemini2/shit/working_mystran','prob_2_005_*cquadr_simo.dat'),
 ('2006','D:/18a/python/linear/working_mystran_2_006','*cquadr_simo.dat'),
 ('2007','D:/18a/python/linear/working_mystran_2_007','prob_2_007_thick_cquadr_simo.dat'),
 ('2008c','D:/18a/bending_only/Shell/gemini2/shit','prob_2_008c_thick.dat'),
 ('2009','D:/18a/MYSTRAN_Validation-main/nx_scratch/decks/shell','prob_2_009*-thick.dat'),
 ('2010','D:/18a/bending_only/Shell/gemini2/shit/working_mystran','prob_2_010_*cquadr_simo.dat'),
 ('2012a','D:/18a/refresh/shell/2012','prob_2_012a-thick.dat'),
 ('2012b','D:/18a/MYSTRAN_Validation-main/nx_scratch/decks/shell','prob_2_012b-thick.dat'),
 ('2013','D:/18a/python/linear/2-014/working_mystran_2_013','*cquadr_simo.dat'),
 ('2014','D:/18a/python/linear/working_mystran_2_014','prob_2_014b_tempgrad_cquadr_simo.dat'),
 ('2016c','D:/18a/MYSTRAN_Validation-main/working','prob_2_016c_thick_beamseg_*.dat'),
 ('2017','D:/18a/python/linear/working_mystran_2_017','*cquadr_dkmq24.dat'),
 ('2050','D:/18a/python/linear/working_mystran_2_050','*cquadr_simo.dat'),
]
S2K = [
 REPO/'SHELL_CHEcK_Q8/production_20261018/originals/shell_s2k',
 REPO/'Shell_check_t6/inputs_20261018/shell_s2k',
 Path('D:/18a/MYSTRAN/Binaries'),
 Path('D:/18a/refresh/shell/reference_sap2j/mct bikinan'),
 Path('D:/18a/refresh/shell/reference_sap2j/mct bikinan/reference_sap2j/mct bikinan'),
 Path('D:/t3ff')]

def simple_case(nodes, quads, tail, E=2.1e6,nu=.3,t=.1,sol=101, rank=False):
    out=[f'SOL {sol}']
    if rank: out+=['OUTPUT4 KGG,,,,//-1/21']
    out+=['CEND','ECHO = NONE','TITLE = COMMON SHELL BENCHMARK']
    out+=['METHOD = 1','DISPLACEMENT = ALL'] if rank else ['SPC = 1','LOAD = 1','DISPLACEMENT = ALL','STRESS = ALL','FORCE = ALL']
    out+=['BEGIN BULK',f'MAT1,1,{E},,{nu},1.',f'PSHELL,1,1,{t},1,,1']
    out += [f'GRID,{n},,{x:.12g},{y:.12g},{z:.12g}' for n,(x,y,z) in nodes.items()]
    out += [','.join(['CQUADR',str(i),'1']+list(map(str,q))) for i,q in enumerate(quads,1)]
    return '\n'.join(out+tail+['ENDDATA'])+'\n'

def rectangle(nx,ny,L,b):
    nodes={i*(ny+1)+j+1:(L*i/nx,b*j/ny,0) for i in range(nx+1) for j in range(ny+1)}
    nid=lambda i,j:i*(ny+1)+j+1
    quads=[(nid(i,j),nid(i+1,j),nid(i+1,j+1),nid(i,j+1)) for i in range(nx) for j in range(ny)]
    return nodes,quads

def extra_cases():
    result=[]
    for shape,xy in [('unit',[(0,0),(1,0),(1,1),(0,1)]),('distorted',[(0,0),(1,0),(1.2,.8),(-.1,1.1)])]:
        nodes={i+1:(x,y,0) for i,(x,y) in enumerate(xy)}
        result.append((f'T1_rank_{shape}',simple_case(nodes,[(1,2,3,4)],['EIGRL,1,1.,,6'],sol=103,rank=True)))
    for n in (1,2,4,8):
        nodes,qs=rectangle(n,1,10,1); tip=[i for i,p in nodes.items() if p[0]==10]
        bc=[f'SPC1,1,123456,{i}' for i,p in nodes.items() if p[0]==0]
        for kind in ('moment','force','axial'):
            card='MOMENT' if kind=='moment' else 'FORCE'; magnitude=500 if kind=='moment' else .5
            direction='0.,1.,0.' if kind=='moment' else ('1.,0.,0.' if kind=='axial' else '0.,0.,1.')
            tail=bc+[f'{card},1,{i},0,{magnitude},{direction}' for i in tip]
            result.append((f'T_cantilever_{kind}_n{n}',simple_case(nodes,qs,tail,nu=.3 if kind=='moment' else 0)))
    for n in (4,8,16):
        nodes,qs=rectangle(n,n,10,10); tail=[]
        for i,(x,y,z) in nodes.items():
            if x in (0,10) or y in (0,10): tail.append(f'SPC1,1,3,{i}')
            if y in (0,10): tail.append(f'SPC1,1,5,{i}')
            if x in (0,10): tail.append(f'SPC1,1,4,{i}')
            factor=(.5 if x in (0,10) else 1)*(.5 if y in (0,10) else 1)
            tail.append(f'FORCE,1,{i},0,{-factor*(10/n)**2},0.,0.,1.')
        tail+=['SPC1,1,126,1',f'SPC1,1,26,{n*(n+1)+1}']
        result.append((f'T_ss_plate_n{n}',simple_case(nodes,qs,tail,nu=0)))
    return result

def build():
    originals=ROOT/'inputs'; originals.mkdir(exist_ok=True)
    refs=ROOT/'references'; refs.mkdir(exist_ok=True)
    provenance=[]; templates=[]
    for group,directory,pattern in SPECS:
        found=sorted(Path(directory).glob(pattern))
        if not found: raise FileNotFoundError(f'{directory}/{pattern}')
        for p in found:
            target=originals/group/p.name; target.parent.mkdir(exist_ok=True); shutil.copy2(p,target)
            provenance.append(dict(group=group,path=str(p),copy=str(target.relative_to(ROOT)),sha256=sha(p)))
            templates.append((group,p.stem,target.read_text(errors='replace'),str(target.relative_to(ROOT))))
    # S2K references: selected cases only, c for 2-008, c/d for 2-003.
    wanted={2:['a'],3:['c','d'],4:[''],5:['c'],6:[''],7:[''],8:['c'],9:['a','b'],10:['a','b'],12:['a','b'],13:['a','b'],14:['b'],17:['']}
    selected={}
    for number,letters in wanted.items():
        for letter in letters:
            stem=f'Example 2-{number:03d}{letter}'
            candidates=[d/(stem+suffix+'.s2k') for suffix in ('-thick','-thin') for d in S2K]
            p=next((p for p in candidates if p.exists()),None)
            if p:
                target=refs/p.name; shutil.copy2(p,target); selected[f'{number:03d}{letter}']=p
                provenance.append(dict(group='s2k',path=str(p),copy=str(target.relative_to(ROOT)),sha256=sha(p)))
                t=tables(p)
                (refs/(p.stem+'.tables.json')).write_text(json.dumps(t,indent=2))
    for letter in ('c',):
        p=selected['003'+letter]
        templates.append(('2003'+letter,'s2k_2003'+letter,s2k_curved(p),'references/'+p.name))
    for key,group in [('002a','2002'),('004','2004')]:
        p=selected[key]
        templates.append((group,'s2k_2'+key,s2k_curved(p),'references/'+p.name))
    for letter in ('a','b'):
        p=selected['010'+letter]
        templates.append(('2010'+letter,'s2k_2010'+letter,cylinder_model(s2k_geometry(p)),'references/'+p.name))
    for name,text in extra_cases(): templates.append(('T',name,text,'generated from test_shell_full_v2aa.py parameters'))
    pdfdir=Path('C:/Program Files/Computers and Structures/SAP2000 20/Manuals/Verification/Analysis/Shells')
    for n in range(1,18):
        p=pdfdir/f'Problem 2-{n:03d}.pdf'; target=refs/p.name
        if not target.exists() or sha(target)!=sha(p): shutil.copyfile(p,target)
        provenance.append(dict(group='pdf',path=str(p),copy=str(target.relative_to(ROOT)),sha256=sha(p)))
    p=Path('D:/18a_sept/python/linear/test_shell_full_v2aa.py'); shutil.copy2(p,refs/p.name)
    provenance.append(dict(group='python_reference',path=str(p),copy='references/'+p.name,sha256=sha(p)))
    manifest=[]; neutral=ROOT/'templates'; neutral.mkdir(exist_ok=True)
    for group,name,text,source in templates:
        if group=='2003_legacy': continue  # retained input, excluded from published c-only study
        if group=='2001':
            text=text.replace('CEND\n','CEND\nFORCE = ALL\n',1)
        if group=='2010': text=cylinder_model(text)
        if group=='2014':
            # Uploaded DAT has alpha in MAT1 TREF, and MID3 blank (thin).
            # Correct both from Example 2-014b-thick before any comparison.
            lines=[]
            for line in text.splitlines():
                f=fields(line)
                if f and f[0]=='MAT1':line='MAT1,1,29000.,,0.3,7.344552904E-7,6.5E-6,0.'
                if f and f[0]=='PSHELL':line='PSHELL,1,1,1.,1,,1'
                lines.append(line)
            text='\n'.join(lines)+'\n'
        if group in ('2012a','2012b'):
            # Match S2K transverse-shear modifiers: a=1, b=1000.
            factor=(5/6)*(1000 if group=='2012b' else 1)
            lines=[]
            for line in text.splitlines():
                f=fields(line)
                if f and f[0]=='PSHELL':
                    while len(f)<8:f.append('')
                    f[7]=real(factor);line=','.join(f)
                lines.append(line)
            text='\n'.join(lines)+'\n'
        # Remove obsolete bailout from benchmark inputs: fatal/singular runs must remain visible.
        text='\n'.join(s for s in text.splitlines() if not re.match(r'\s*PARAM\s*,\s*BAILOUT\s*,',s,re.I))+'\n'
        if group=='2016c':
            # Both supplied files contain both load cases; select one and use a
            # true static preload plus linked buckling subcase, as required by MYSTRAN.
            sid=10 if 'shear' in name else 20
            text='SOL 105\nCEND\nECHO = NONE\nSPC = 1\nSUBCASE 1\n LOAD = '+str(sid)+'\n DISPLACEMENT = ALL\n STRESS(CENTER,CORNER) = ALL\nSUBCASE 2\n METHOD = 1\n STATSUB(PRELOAD) = 1\nBEGIN BULK'+text.split('BEGIN BULK',1)[1]
            text=edge_tractions(text)
        text=normalize_reals(text)
        (neutral/(name+'.dat')).write_text(text)
        tri=normalize_reals(triangulate(text))
        for el,param,value in FORMS+TRI_FORMS:
            base=tri if el in ('CTRIA3','CTRIAR') else text
            expected=canonical(base)
            generated=variant(base,el,param,value)
            assert canonical(generated)==expected, (name,el,value)
            label=el+'_'+value.replace('+','plus')
            p=ROOT/'decks'/name/label/'model.dat'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(generated)
            manifest.append(dict(case=name,group=group,formulation=label,element=el,param=param,value=value,
                deck=str(p.relative_to(ROOT)),sha256=sha(p),physics_sha256=expected,source=source,
                solution=re.search(r'SOL\s+(\d+)',text)[1],nodes=len(grids(base)),
                quads=sum(f[0] in ('CQUADR','CQUAD4') for f in cards(base)),
                triangles=sum(f[0] in ('CTRIA3','CTRIAR') for f in cards(base))))
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
    (ROOT/'provenance.json').write_text(json.dumps(provenance,indent=2))
    with (ROOT/'matrix.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(manifest[0])); w.writeheader(); w.writerows(manifest)
    print(f'Built {len(set(r["case"] for r in manifest))} cases x {len(FORMS+TRI_FORMS)} formulations = {len(manifest)} decks')

if __name__=='__main__': build()

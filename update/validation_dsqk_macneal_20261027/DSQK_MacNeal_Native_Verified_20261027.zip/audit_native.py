from pathlib import Path
import sys,json,subprocess,hashlib,os
import numpy as np
from scipy.sparse.linalg import spsolve
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P/'input/python_reference'),str(P/'input/support')]
from assemble_reference import assemble
from results import parse_f06,kgg
from DSQK_ConsistentSpin_CovShear_MixedElimination import DSQK_ConsistentSpin_CovShear_MixedElimination as HY
from build_suite import cards,grids
exe=Path('H:/Projects/MYSTRAN/codex_mod/dsqk_mixed_upgrade_20261026/bin/mystran.exe')
rows=[]
for deck in sorted((P/'python_rerun').glob('*.dat')):
 d=P/'native'/deck.stem;d.mkdir(parents=True,exist_ok=True)
 text=deck.read_text().replace('SOL 101','SOL 101\nOUTPUT4 KGG,,,,//-1/21',1)
 (d/'model.dat').write_text(text)
 env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 with (d/'console.log').open('w') as log: subprocess.run([str(exe),'model.dat'],cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 f=(d/'model.F06').read_text(errors='replace');assert '*ERROR' not in f and 'END OF JOB' in f
 nk=kgg(d/'model.OU1');K,F,free,ids,Q,els=assemble(deck,HY);pk=K.toarray()
 matrix_error=float(np.linalg.norm(pk-nk)/np.linalg.norm(pk));assert matrix_error<1e-11
 data=parse_f06(d/'model.F06','MYSTRAN');cs=cards(text)
 for lc,nodal in data['displacements'].items():
  u=np.zeros(len(ids)*6)
  for c in cs:
   if c[0]=='SPCD' and int(c[1])==lc:u[6*ids.index(int(c[2]))+int(c[3])-1]=float(c[4])
  u[free]=spsolve(K[free,:][:,free],-(K@u)[free])
  v=np.array([nodal[n] for n in ids]).ravel();delta=(v-u).reshape(-1,6)
  energy_native=float(.5*v@nk@v);energy_python=float(.5*u@pk@u)
  reaction_delta=float(np.linalg.norm(nk@v-pk@u)/max(np.linalg.norm(pk@u),1e-30))
  row=dict(deck=deck.name,loadcase=lc,matrix_relative_difference=matrix_error,translation_difference_in=float(abs(delta[:,:3]).max()),rotation_difference_rad=float(abs(delta[:,3:]).max()),energy_native_matrix_F06=energy_native,energy_python=energy_python,energy_relative_difference=abs(energy_native/energy_python-1),reconstructed_reaction_relative_difference=reaction_delta)
  assert row['translation_difference_in']<1e-9 and row['rotation_difference_rad']<1e-9
  rows.append(row);print(row,flush=True)
(P/'native_results.json').write_text(json.dumps(dict(binary=str(exe),binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),results=rows),indent=2))

Quadratic shell benchmark: published comparison tables
Source commit: 06d7f92bdf6d67f443d77db487ccc3ab6ac3fa64
Tables: 28

The original combined quadratic CSV was not found. These CSV files transcribe the published Markdown tables at their published precision; they are not full-precision solver exports. Source Markdown is included to preserve units, definitions, warnings, missing results, and exclusions. No solver was rerun and no missing value was filled. Cells retain their published text, including flags and formatting.

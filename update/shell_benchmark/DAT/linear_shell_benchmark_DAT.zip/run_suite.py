"""Run manifest cases in isolated directories; preserve failures and solver hashes."""
from pathlib import Path
import argparse, concurrent.futures, hashlib, json, os, re, subprocess, time
ROOT=Path(__file__).resolve().parent

def run(row,solver,timeout,resume):
    deck=ROOT/row['deck']; result=deck.parent/'run.json'
    fingerprint=hashlib.sha256(solver.read_bytes()).hexdigest()
    if resume and result.exists():
        old=json.loads(result.read_text())
        if old.get('solver_sha256')==fingerprint and old.get('deck_sha256')==row['sha256']: return old
    started=time.time(); status='not_run'; rc=None
    env=os.environ.copy(); env['OMP_NUM_THREADS']='1'; env['OPENBLAS_NUM_THREADS']='1'
    with (deck.parent/'console.log').open('w') as log:
        try:
            p=subprocess.run([str(solver),deck.name],cwd=deck.parent,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=timeout)
            rc=p.returncode
        except subprocess.TimeoutExpired: status='timeout'
    log=(deck.parent/'console.log').read_text(errors='replace')
    f06=deck.with_suffix('.F06'); text=f06.read_text(errors='replace') if f06.exists() else ''
    errors=re.findall(r'\*ERROR[^\n]*|\*FATAL[^\n]*',text+'\n'+log)
    warnings=re.findall(r'\*WARNING[^\n]*',text)
    if status!='timeout':
        status='completed' if rc==0 and 'MYSTRAN terminated normally' in log and not errors else 'solver_error'
    result_data=dict(case=row['case'],formulation=row['formulation'],deck=row['deck'],status=status,
        returncode=rc,seconds=round(time.time()-started,3),solver=str(solver),solver_sha256=fingerprint,
        deck_sha256=row['sha256'],errors=list(dict.fromkeys(errors)),warnings=list(dict.fromkeys(warnings)),
        verification='NOT_EVALUATED')
    result.write_text(json.dumps(result_data,indent=2)); return result_data

def main():
    p=argparse.ArgumentParser(); p.add_argument('--solver',type=Path,default=ROOT.parent/'source/Binaries/mystran.exe')
    p.add_argument('--filter',default=''); p.add_argument('--jobs',type=int,default=4); p.add_argument('--timeout',type=int,default=240)
    p.add_argument('--resume',action='store_true'); args=p.parse_args()
    rows=[r for r in json.loads((ROOT/'manifest.json').read_text()) if re.search(args.filter,r['case']+'/'+r['formulation'])]
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        tasks=[pool.submit(run,r,args.solver.resolve(),args.timeout,args.resume) for r in rows]
        for future in concurrent.futures.as_completed(tasks):
            results.append(future.result())
            if len(results)%30==0 or len(results)==len(rows): print(f'{len(results)}/{len(rows)} runs, {sum(r["status"]=="completed" for r in results)} completed',flush=True)
    (ROOT/'run_summary.json').write_text(json.dumps(results,indent=2))
    print('Solver completion is separate from numerical verification.',flush=True)

if __name__=='__main__': main()

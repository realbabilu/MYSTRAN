Tested linear decks: MYSTRAN rerun 27 October 2026, Nastran reference outputs retained. Base b1da4a6a plus tested_source_candidate.patch. Solver not included. 1e-6 buckling residual limit unchanged.

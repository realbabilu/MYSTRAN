# Executed linear shell DAT archive

MYSTRAN and NASTRAN directories contain the exact tested decks, including known failures. manifest.json / nastran_manifest.json contain relative paths and SHA256s. Source base21540039 plus tested_source_candidate.patch defines the MYSTRAN element snapshot. SF is a candidate, not a blanket production certification.

With NumPy installed, run python run_suite.py --solver /absolute/path/to/matching/mystran.exe --jobs 4. Use your licensed Nastran in the separate NASTRAN tree; special unit-reaction rank decks are adjacent *_rank.dat files. Then python results.py extracts relative paths using the same declared observables. Re-running requires a matching built executable and normal solver dependencies; no executable is bundled.

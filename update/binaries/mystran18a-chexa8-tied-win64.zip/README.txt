MYSTRAN 18.0.A CHEXA8 TIED update, 18 October 2026.
Keep libopenblas.dll beside mystran.exe. TIED is provisional: 20 Nastran jobs completed; accuracy acceptance remains scoped. Explicit-IN=2 and historical default-integration references are distinct.
HEXATYP=TIED default; EAS9 retains previous formulation. HEXATAX=ZETA default; AUTO is opt-in.
See repository update/chexa8_tied_2026-10-18.md.

MYSTRAN linear-shell benchmark snapshot, 25 October 2026.
Source 21540039 plus tested_source_candidate.patch.
DKMT18 SF is a candidate with documented trade-offs. Corrected DSG3 BEND six-mode residual failure remains open.
No shared solver defaults or residual acceptance limits changed.
See update/shell_benchmark/PUBLICATION_QA_linear.md.
Place libopenblas.dll beside mystran.exe.
